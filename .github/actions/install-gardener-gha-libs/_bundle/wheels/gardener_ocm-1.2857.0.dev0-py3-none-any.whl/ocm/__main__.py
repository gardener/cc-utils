import argparse
import base64
import collections.abc
import dataclasses
import datetime
import enum
import functools
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import textwrap

import cryptography.exceptions
import cryptography.hazmat.primitives.asymmetric.padding
import cryptography.hazmat.primitives.asymmetric.utils
import cryptography.hazmat.primitives.hashes
import cryptography.x509
import dacite

import ctt.__main__
import oci.client
import oci.model
import ocm
import ocm.access
import ocm.gardener
import ocm.helm
import ocm.iter
import ocm.oci
import ocm.prune
import ocm.retrieve
import ocm.sign
import ocm.upload

own_dir = os.path.dirname(__file__)


try:
    import yaml
    _have_yaml = True
except ImportError:
    _have_yaml = False

try:
    import oci
    import oci.auth
    import oci.client
    _have_oci = True
except ImportError:
    _have_oci = False


if _have_yaml:
    _yaml_or_json_load = yaml.safe_load
else:
    _yaml_or_json_load = json.load


def _parse_yaml_or_json(path) -> dict | list:
    with open(path) as f:
        return _yaml_or_json_load(f)


def dump(component_descriptor: ocm.ComponentDescriptor, parsed):
    if parsed.out == '-':
        outfh = sys.stdout
    else:
        outfh = open(parsed.out, 'w')

    raw_dict = dataclasses.asdict(component_descriptor)

    if _have_yaml:
        yaml.dump(
            data=raw_dict,
            stream=outfh,
            Dumper=ocm.EnumValueYamlDumper,
        )
    else:
        json.dump(
            obj=raw_dict,
            fp=outfh,
            cls=ocm.EnumJSONEncoder,
        )
    outfh.flush()


def _iter_parsed_labels(labels) -> collections.abc.Generator[ocm.Label, None, None]:
    '''
    parses the passed labels (which is expected to be str-instances in YAML/JSON format) into
    OCM-Labels.
    '''
    for label in labels:
        if os.path.exists(label):
            label = _parse_yaml_or_json(label)
        else:
            label = _yaml_or_json_load(label)

        if isinstance(label, list):
            label_entries = label
        elif isinstance(label, dict):
            label_entries = (label,)
        else:
            print(f'Error: --label must be either an array, or an object. got: {label=}')
            exit(1)

        for label in label_entries:
            yield ocm.Label(
                name=label['name'],
                value=label['value'],
            )


def create(parsed):
    now_ts = datetime.datetime.now(datetime.timezone.utc).isoformat(
        timespec='seconds',
    ).removesuffix('+00:00') + 'Z'

    if parsed.ocm_repository:
        ocm_repos = [
            ocm.OciOcmRepository(baseUrl=parsed.ocm_repository),
        ]
    else:
        ocm_repos = []

    component_descriptor = ocm.ComponentDescriptor(
        meta=ocm.Metadata(),
        component=ocm.Component(
            name=parsed.name,
            version=parsed.version,
            repositoryContexts=ocm_repos,
            provider=parsed.provider,
            componentReferences=[],
            sources=[],
            resources=[],
            labels=list(_iter_parsed_labels(labels=parsed.labels)),
            creationTime=now_ts,
        ),
        signatures=[],
    )

    dump(component_descriptor, parsed)


def append(parsed):
    raw = _parse_yaml_or_json(parsed.file)

    component = raw['component']

    attr = None
    if parsed.type in ('r', 'resource'):
        attr = component['resources']
        ocm_cls = ocm.Resource

    elif parsed.type in ('s', 'source'):
        attr = component['sources']
        ocm_cls = ocm.Source

    elif parsed.type in ('c', 'component-reference'):
        attr = component['componentReferences']
        ocm_cls = ocm.ComponentReference
    elif parsed.type in ('l', 'component-label'):
        attr = component['labels']
        ocm_cls = None

    labels = list(_iter_parsed_labels(labels=labels)) if (labels := parsed.labels) else []

    if ocm_cls is None:
        # special-case: component-labels
        attr.extend(labels)
    else:
        if _have_yaml:
            obj = yaml.safe_load(sys.stdin)
        else:
            obj = json.load(sys.stdin)

        obj = obj if isinstance(obj, list) else [obj]

        artefacts = [
            dacite.from_dict(
                data_class=ocm_cls,
                data=o,
                config=dacite.Config(
                    cast=(enum.Enum,),
                ),
            )
            for o in obj
        ]

        for artefact in artefacts:
            artefact.labels = list(artefact.labels) + labels

        attr: list
        attr.extend([dataclasses.asdict(a) for a in artefacts])

    with open(parsed.file, 'w') as f:
        if _have_yaml:
            yaml.dump(
                data=raw,
                stream=f,
                Dumper=ocm.EnumValueYamlDumper,
            )
        else:
            json.dump(raw, f)


def upload(parsed):
    if not _have_oci:
        print('ERROR: `oci`-package is not available - cannot upload')
        exit(1)

    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(),
    )
    component_descriptor = ocm.ComponentDescriptor.from_dict(_parse_yaml_or_json(parsed.file))
    component = component_descriptor.component
    if parsed.ocm_repository:
        component.repositoryContexts.append(
            ocm.OciOcmRepository(baseUrl=parsed.ocm_repository),
        )

    ocm_tgt_repo = component_descriptor.component.current_ocm_repo
    if not ocm_tgt_repo:
        print('ERROR: must define ocm-repository either via --ocm-repository')
        print('       or via component-descriptor (repositoryContexts)')
        exit(1)

    oci_target_ref = component.current_ocm_repo.component_version_oci_ref(component)

    for artefact in component.iter_artefacts():
        access = artefact.access
        if not access:
            continue

        if not access.type is ocm.AccessType.LOCAL_BLOB:
            continue

        # upload local-blobs, if needed
        if oci_client.head_blob(
            image_reference=oci_target_ref,
            digest=access.localReference,
            absent_ok=True,
        ):
            continue # no need to upload again
        blob_path_candidates = (
            os.path.join(
                parsed.blobs_dir,
                access.localReference.removeprefix('sha256:')
            ),
            os.path.join(
                parsed.blobs_dir,
                access.localReference,
            ),
        )
        for candidate in blob_path_candidates:
            if not os.path.exists(candidate):
                continue

        if not os.path.exists(candidate):
            print(f'error: did not find expected blob at {candidate=}')
            print(f'this blob was expected for {artefact=}')
            exit(1)
        with open(candidate, 'rb') as f:
            oci_client.put_blob(
                image_reference=oci_target_ref,
                digest=access.localReference,
                octets_count=access.size,
                data=f,
            )

    print(f'Uploading OCM Component-Descriptor to: {oci_target_ref=}')
    print(f'{parsed.on_exist=}')
    ocm.upload.upload_component_descriptor(
        component_descriptor=component_descriptor,
        oci_client=oci_client,
        on_exist=parsed.on_exist,
    )


def download(parsed):
    if not _have_oci:
        print('ERROR: `oci`-package is not available - cannot download')
        exit(1)

    cname, cversion = parsed.component.split(':')
    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(absent_ok=True),
    )

    ocm_repo = ocm.OciOcmRepository(
        baseUrl=parsed.ocm_repository,
    )

    def _fetch_component_descriptor(
        name: str,
        version: str,
        ocm_repo: ocm.OciOcmRepository | str | None=None,
    ) -> ocm.ComponentDescriptor:
        target_ref = ocm_repo.component_version_oci_ref(
            name=name,
            version=version
        )
        manifest = oci_client.manifest(
            image_reference=target_ref
        )
        try:
            cfg_blob = oci_client.blob(
                image_reference=target_ref,
                digest=manifest.config.digest
            )
            cfg_raw = json.loads(cfg_blob.text)
            cfg = dacite.from_dict(
                data_class=ocm.oci.ComponentDescriptorOciCfg,
                data=cfg_raw
            )
            layer_digest = cfg.componentDescriptorLayer.digest
            layer_mimetype = cfg.componentDescriptorLayer.mediaType
        except Exception as e:
            print(f'Failed to retrieve component-descriptor-cfg: {e=}, falling back to first layer')

            # by contract, the first layer must always be a tar w/ component-descriptor
            layer_digest = manifest.layers[0].digest
            layer_mimetype = manifest.layers[0].mediaType

        if not layer_mimetype in ocm.oci.component_descriptor_mimetypes:
            print(f'Error: {target_ref=} {layer_mimetype=} was unexpected')
            exit(1)

        raw = oci_client.blob(
            image_reference=target_ref,
            digest=layer_digest,
            stream=False, # manifests are typically small - do not bother w/ streaming
        ).content

        return ocm.oci.component_descriptor_from_blob(
            component_descriptor_blob=raw,
            layer_mimetype=layer_mimetype,
            target_ref=target_ref,
            component_id=ocm.ComponentIdentity(
                name=name,
                version=version,
            ),
        )

    root_component_descriptor = _fetch_component_descriptor(
        name=cname,
        version=cversion,
        ocm_repo=ocm_repo
    )
    component = root_component_descriptor.component

    if parsed.outfile == '-':
        outfh = sys.stdout.buffer
    else:
        outfh = open(parsed.outfile, 'wb')

    if (t := parsed.type) in ('component-descriptor', 'c'):
        if parsed.name:
            sub_name = parsed.name
            for cnode in ocm.iter.iter(
                component=component,
                lookup=lambda cid, repo=None: _fetch_component_descriptor(
                    name=cid.name,
                    version=cid.version,
                    ocm_repo=(repo or ocm_repo),
                ),
                node_filter=ocm.iter.Filter.components,
                ocm_repo=ocm_repo,
            ):
                if cnode.component.name == sub_name:
                    root_component_descriptor = _fetch_component_descriptor(
                        name=cnode.component.name,
                        version=cnode.component.version,
                        ocm_repo=ocm_repo,
                    )
                    break
            else:
                print(f'Error: did not find {sub_name=} in component-tree of {cname}:{cversion}')
                exit(1)

        yaml.dump(
            data=dataclasses.asdict(root_component_descriptor),
            stream=outfh,
            encoding='utf-8',
            Dumper=ocm.EnumValueYamlDumper,
        )
        if parsed.recursive:
            for node in ocm.iter.iter(
                component=component,
                lookup=lambda cid, repo=None: _fetch_component_descriptor(
                    name=cid.name,
                    version=cid.version,
                    ocm_repo=(repo or ocm_repo)
                ),
                recursion_depth=-1,
                prune_unique=True,
                node_filter=ocm.iter.Filter.components,
                ocm_repo=ocm_repo,
            ):
                comp = node.component
                if comp.name == component.name and comp.version == component.version:
                    continue

                component_descriptor = _fetch_component_descriptor(
                    name=comp.name,
                    version=comp.version,
                    ocm_repo=ocm_repo
                )
                outfh.write(b'---\n')
                yaml.dump(
                    data=dataclasses.asdict(component_descriptor),
                    stream=outfh,
                    encoding='utf-8',
                    Dumper=ocm.EnumValueYamlDumper,
                )

        outfh.flush()
        if outfh is not sys.stdout.buffer:
            outfh.close()
        exit(0)

    elif t in ('resource', 'r'):
        artefacts = component.resources
    elif t in ('source', 's'):
        artefacts = component.sources
    else:
        raise ValueError(f'unexpected {parsed.type=} - this is a bug')

    artefact = None
    if len(artefacts) < 1:
        print(f'Error: {cname}:{cversion} has no artefacts of {parsed.type=}')
        exit(1)
    elif len(artefacts) == 1:
        artefact = artefacts[0]

    name = parsed.name
    id_attrs = {}
    for attrspec in parsed.artefact_ids:
        key, value = attrspec.split('=')
        id_attrs[key] = value

    have_id = bool(name or id_attrs)

    if not have_id and len(artefacts) > 1:
        print('Error: must specify artefact-id')
        exit(1)

    matches = 0
    if have_id:
        for a in artefacts:
            if name != a.name:
                continue

            for k,v in id_attrs.items():
                if hasattr(a, k):
                    if getattr(a, k) != v:
                        break
                else:
                    if not k in a.extraIdentity:
                        break
                    if a.extraIdentity[k] != v:
                        break
            else:
                # if there was no break, we have a candidate
                matches += 1
                artefact = a

    if not artefact:
        print(f'Error: did not find artefact {name=} {id_attrs=}')
        exit(1)

    if matches > 1:
        print(f'Error: artefact was not specified unambiguously: {name=} {id_attrs=}')
        exit(1)

    # at this point, we have one single, and unambiguously specified artefact
    access = artefact.access
    image_ref = None
    digest = None

    if access.type is ocm.AccessType.LOCAL_BLOB:
        image_ref = component.current_ocm_repo.component_version_oci_ref(
            name=cname,
            version=cversion,
        )
        digest = access.localReference

    elif access.type is ocm.AccessType.OCI_REGISTRY:
        if not artefact.type is ocm.ArtefactType.HELM_CHART:
            print(f'Error: {artefact.type=} not implemented for ociRegistry access')
            exit(1)

        image_ref = access.imageReference
        manifest = oci_client.manifest(image_reference=access.imageReference)

        target_mime = 'application/vnd.cncf.helm.chart.content.v1.tar+gzip'
        helm_chart_layer = None
        for layer in manifest.layers:
            if layer.mediaType == target_mime:
                helm_chart_layer = layer
                break
        if not helm_chart_layer:
            print(f'Error: expected Helm chart layer ({target_mime})')
            exit(1)

        digest = helm_chart_layer.digest

    else:
        print(f'Error: {access.type=} not implemented')
        exit(1)
    blob_rq = oci_client.blob(
        image_reference=image_ref,
        digest=digest,
    )

    for chunk in blob_rq.iter_content(chunk_size=8192):
        outfh.write(chunk)
    outfh.flush()


def replicate(parsed):
    ctt.__main__.replicate(parsed)


def _traverse(parsed):
    node_kinds = parsed.node_kinds

    if 'c' in node_kinds:
        components = True
    else:
        components = False

    if 'r' in node_kinds:
        resources = True
    else:
        resources = False

    if 's' in node_kinds:
        sources = True
    else:
        sources = False

    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_cfg,
        ),
    )

    component_descriptor_lookup = ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(parsed.ocm_repository),
        oci_client=oci_client,
    )
    component = component_descriptor_lookup(parsed.name)

    traverse(
        component=component,
        components=components,
        sources=sources,
        resources=resources,
        component_descriptor_lookup=component_descriptor_lookup,
        output_format=parsed.format,
        print_expr=parsed.print_expr,
        filter_expr=parsed.filter_expr,
        recursive=parsed.recursive,
    )


def traverse(
    component: ocm.Component,
    components: bool,
    sources: bool,
    resources: bool,
    component_descriptor_lookup,
    output_format: str,
    print_expr: str=None,
    filter_expr: str=None,
    recursive: bool=False,
):
    if output_format == 'pretty':
        print_incrementally = True
    elif output_format in ('json', 'yaml'):
        print_incrementally = False
    else:
        raise ValueError(format)

    if recursive is True:
        recursion_depth = -1
    else:
        recursion_depth = 0

    def iter_nodes():
        for node in ocm.iter.iter(
            component=component,
            lookup=component_descriptor_lookup,
            recursion_depth=recursion_depth,
        ):
            is_component_node = isinstance(node, ocm.iter.ComponentNode)
            is_source_node = isinstance(node, ocm.iter.SourceNode)
            is_resource_node = isinstance(node, ocm.iter.ResourceNode)

            if is_component_node and not components:
                continue

            if is_source_node and not sources:
                continue

            if is_resource_node and not resources:
                continue

            if filter_expr:
                if is_component_node:
                    typestr = 'component'
                    artefact = None
                elif is_source_node:
                    typestr = node.source.type
                    artefact = node.source
                elif is_resource_node:
                    typestr = node.resource.type
                    artefact = node.resource

                if isinstance(typestr, enum.Enum):
                    typestr = typestr.value

                if not eval(filter_expr, { # nosec B307
                    'node': node,
                    'type': typestr,
                    'artefact': artefact,
                }):
                    continue
            yield node

    if print_incrementally:
        for node in iter_nodes():
            indent = len(node.path * 2)

            is_component_node = isinstance(node, ocm.iter.ComponentNode)
            is_source_node = isinstance(node, ocm.iter.SourceNode)
            is_resource_node = isinstance(node, ocm.iter.ResourceNode)

            if is_component_node:
                if not print_expr:
                    prefix = 'c'
                    print(f'{prefix}{" " * indent}{node.component.name}:{node.component.version}')
                else:
                    print(eval(print_expr, {'node': node, 'artefact': None})) # nosec B307
            if is_resource_node:
                if not print_expr:
                    prefix = 'r'
                    indent += 1
                    print(f'{prefix}{" " * indent}{node.resource.name}')
                else:
                    print(eval(print_expr, {'node': node, 'artefact': node.resource})) # nosec B307
            if is_source_node:
                if not print_expr:
                    prefix = 's'
                    indent += 1
                    print(f'{prefix}{" " * indent}{node.source.name}')
                else:
                    print(eval(print_expr, {'node': node, 'artefact': node.source})) # nosec B307
        return

    # print single json or yaml document
    objects = list()
    for node in iter_nodes():
        if isinstance(node, ocm.iter.ComponentNode):
            obj = dataclasses.asdict(node.component)
        else:
            obj = dataclasses.asdict(node.artefact)
        objects.append(obj)

    if output_format == 'json':
        print(json.dumps(objects, cls=ocm.EnumJSONEncoder))
    elif output_format == 'yaml':
        print(yaml.dump(data=objects, Dumper=ocm.EnumValueYamlDumper))
    else:
        raise ValueError(output_format)


def imagevector(parsed):
    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_cfg,
        ),
    )

    component_descriptor_lookup = ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(parsed.ocm_repository),
        oci_client=oci_client,
    )
    root_component = component_descriptor_lookup(parsed.root_name).component

    if not parsed.recursive:
        if not parsed.name:
            print('Error: must pass --name if not using --recursive')
            exit(1)
        if ':' in parsed.name:
            component = component_descriptor_lookup(parsed.name)
        else:
            component_name = parsed.name
            for cnode in ocm.iter.iter(
                component=root_component,
                lookup=component_descriptor_lookup,
                node_filter=ocm.iter.Filter.components,
            ):
                if cnode.component.name == component_name:
                    component = cnode.component
                    break
            else:
                print(
                  f'Error: did not find version for {component_name=} in {root_component.name=}'
                )
                exit(1)

        if parsed.subcomponent_ref_name:
            ref_name = parsed.subcomponent_ref_name
            parent = component.component
            for cref in parent.componentReferences:
                if ref_name in (cref.name, cref.componentName):
                    component = component_descriptor_lookup(cref).component
                    break
            else:
                print(f'Error: componentReference {ref_name!r} not found in {parent.name}')
                exit(1)

        components = (component,)
    else:
        def filter_expr(node):
            if not parsed.filter_expr:
                return True
            return eval( # nosec B307
                parsed.filter_expr, {
                    'node': node,
                    'component': node.component,
                })

        components = (
            node.component for node in
            ocm.iter.iter(
                component=root_component,
                lookup=component_descriptor_lookup,
                node_filter=ocm.iter.Filter.components,
            )
            if filter_expr(node)
        )

    images = []
    seen_names = set()

    for component in components:
        for image in ocm.gardener.iter_oci_image_dicts_from_rooted_component(
            component=component,
            root_component=root_component,
            component_descriptor_lookup=component_descriptor_lookup,
        ):
            name = image['name']
            target_version = image.get('targetVersion')
            if (name, target_version) in seen_names:
                continue
            seen_names.add((name, target_version))
            images.append(image)

        if parsed.select_images == 'all':
            for resource in component.resources:
                if not resource.type is ocm.ArtefactType.OCI_IMAGE:
                    continue
                if ((name := resource.name), (target_version := None)) in seen_names:
                    continue

                seen_names.add((name, target_version))
                image_ref = oci.model.OciImageReference.to_image_ref(
                    resource.access.imageReference,
                )

                images.append({
                    'name': name,
                    'repository': image_ref.ref_without_tag,
                    'tag': image_ref.tag,
                })

    if parsed.subcomponent_ref_name:
        subcomponent_overwrite = ocm.gardener.as_image_vector(images=images)
        result = {
            'components': [
                {
                    'name': parsed.subcomponent_ref_name,
                    'imageVectorOverwrite': yaml.dump(subcomponent_overwrite),
                }
            ]
        }
        print(yaml.safe_dump(result))
    else:
        imagevector = ocm.gardener.as_image_vector(images=images)
        print(yaml.safe_dump(imagevector))


def helm_values(parsed):
    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_cfg,
        ),
    )

    component_descriptor_lookup = ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(parsed.ocm_repository),
        oci_client=oci_client,
    )

    component = component_descriptor_lookup(parsed.component).component

    resource = parsed.resource
    if ':' in resource:
        resource_name, resource_version = resource.split(':')
    else:
        resource_name = resource
        resource_version = None

    values = ocm.helm.localised_helmchart_values(
        component=component,
        oci_client=oci_client,
        resource_name=resource_name,
        resource_version=resource_version,
        resource_extra_id=None,
        component_descriptor_lookup=component_descriptor_lookup,
    )

    print(yaml.safe_dump(values))


def _normalise(parsed) -> tuple[ocm.ComponentDescriptor, str]:
    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_cfg,
        ),
    )

    component_descriptor_lookup = ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(parsed.ocm_repository),
        oci_client=oci_client,
    )

    component_descriptor = component_descriptor_lookup(parsed.name)

    access_to_digest_lookup = functools.partial(
        ocm.access.access_to_digest_lookup,
        oci_client=oci_client,
    )

    # todo: change normalise-function to return serialised form (aka str)
    normalised = ocm.sign.normalise_component_descriptor(
        component_descriptor=component_descriptor,
        component_descriptor_lookup=component_descriptor_lookup,
        access_to_digest_lookup=access_to_digest_lookup,
        verify_digests=parsed.validate_digests,
    )

    serialised_and_normalised = json.dumps(
        obj=normalised,
        separators=(',', ':'), # remove spaces as required by OCM-Spec
    )

    return component_descriptor, serialised_and_normalised


def normalise(parsed):
    _, normalised = _normalise(parsed)
    print(normalised)


def validate(parsed):
    component_descriptor, normalised = _normalise(parsed)

    digest = hashlib.sha256(normalised.encode('utf-8')).digest()

    with open(parsed.ca_file, 'rb') as f:
        certificates = cryptography.x509.load_pem_x509_certificates(
            data=f.read(),
        )

    def parse_signature(pem: str) -> bytes:
        start_str = '-----BEGIN SIGNATURE-----'
        start_idx = pem.find(start_str)
        end_str = '-----END SIGNATURE-----'
        end_idx = pem.find(end_str)

        signature = pem[start_idx + len(start_str):end_idx].strip() # strip header and footer
        # strip pre-ambel (Signature Algorithm: <alg>) + blank line
        start_idx = signature.find('\n')
        signature = signature[start_idx + 1:]

        return base64.b64decode(signature.strip())

    cpadding = cryptography.hazmat.primitives.asymmetric.padding
    cutils = cryptography.hazmat.primitives.asymmetric.utils
    chashes = cryptography.hazmat.primitives.hashes

    for signature in component_descriptor.signatures:
        print(f'checking {signature.name=}')
        signature_bytes = parse_signature(signature.signature.value)

        for certificate in certificates:
            public_key = certificate.public_key()

            try:
                public_key.verify(
                    signature=signature_bytes,
                    data=digest,
                    padding=cpadding.PSS(
                        mgf=cpadding.MGF1(chashes.SHA256()),
                        salt_length=cpadding.PSS.MAX_LENGTH,
                    ),
                    algorithm=cutils.Prehashed(chashes.SHA256()),
                )
                print(f'{signature.name=} was valid - existing now')
                return
            except cryptography.exceptions.InvalidSignature:
                print(f'{signature.name=} was invalid (if there are more, will try those)')
                continue

    print('Error: no valid signature was found')
    exit(1)


def generate_config(parsed):
    simple_cfg_script_path = os.path.join(
        own_dir,
        '../ctt/simple-cfg',
    )

    # strip toplevel-command and delegate
    os.execv(simple_cfg_script_path, sys.argv[1:])


def edit(parsed):
    if not _have_oci:
        print('ERROR: `oci`-package is not available - cannot edit')
        exit(1)

    cname, cversion = parsed.component.split(':')
    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_cfg,
        ),
    )

    ocm_repo = ocm.OciOcmRepository(baseUrl=parsed.ocm_repository)
    oci_ref = ocm_repo.component_version_oci_ref(name=cname, version=cversion)

    manifest = oci_client.manifest(image_reference=oci_ref)

    cfg_blob = oci_client.blob(
        image_reference=oci_ref,
        digest=manifest.config.digest,
    )
    oci_cfg: ocm.oci.ComponentDescriptorOciCfg = dacite.from_dict(
        data_class=ocm.oci.ComponentDescriptorOciCfg,
        data=json.loads(cfg_blob.text),
    )

    cd_blob = oci_client.blob(
        image_reference=oci_ref,
        digest=oci_cfg.componentDescriptorLayer.digest,
    )

    tar = tarfile.open(
        fileobj=io.BytesIO(cd_blob.content),
        mode='r:*',
    )
    # component-descriptor must be first entry in tarfile
    cd_info = tar.next()
    reader = tar.extractfile(cd_info)

    with tempfile.NamedTemporaryFile(suffix='.yaml', delete=False) as tf:
        tmp_path = tf.name
        digest = hashlib.sha256()
        while chunk := reader.read(tarfile.BLOCKSIZE):
            tf.write(chunk)
            digest.update(chunk)
        tar.close()
        tf.flush()
        old_digest = digest.hexdigest()

    subprocess.run((parsed.editor, tmp_path), check=True)

    # vi (re)creates files on write -> re-open filehandle
    with open(tmp_path, 'rb') as f:
        raw = f.read()

    os.unlink(tmp_path)

    new_digest = hashlib.sha256(raw).hexdigest()
    if new_digest == old_digest:
        print('no changes - exiting')
        exit(0)

    # build updated tar in-memory to know digest before uploading
    buf = io.BytesIO()
    out_tar = tarfile.open(fileobj=buf, mode='w')
    info = tarfile.TarInfo(name='component-descriptor.yaml')
    info.size = len(raw)
    out_tar.addfile(info, io.BytesIO(raw))
    out_tar.close()
    tar_len = buf.tell()
    buf.seek(0)
    tar_digest = f'sha256:{hashlib.sha256(buf.read()).hexdigest()}'
    buf.seek(0)

    oci_client.put_blob(
        image_reference=oci_ref,
        digest=tar_digest,
        octets_count=tar_len,
        data=buf,
    )

    old_layer_digest = oci_cfg.componentDescriptorLayer.digest
    manifest.layers = [
        layer for layer in manifest.layers
        if layer.digest != old_layer_digest
    ] + [oci.model.OciBlobRef(
        digest=tar_digest,
        mediaType=ocm.oci.component_descriptor_mimetype,
        size=tar_len,
    )]

    oci_cfg.componentDescriptorLayer.digest = tar_digest
    oci_cfg_raw = json.dumps(dataclasses.asdict(oci_cfg)).encode('utf-8')
    oci_cfg_digest = f'sha256:{hashlib.sha256(oci_cfg_raw).hexdigest()}'
    manifest.config = dataclasses.replace(
        manifest.config,
        digest=oci_cfg_digest,
        size=len(oci_cfg_raw),
    )

    oci_client.put_blob(
        image_reference=oci_ref,
        digest=oci_cfg_digest,
        octets_count=len(oci_cfg_raw),
        data=io.BytesIO(oci_cfg_raw),
    )

    oci_client.put_manifest(
        image_reference=oci_ref,
        manifest=json.dumps(manifest.as_dict()),
    )


def main():
    parser = argparse.ArgumentParser()
    maincmd_parsers = parser.add_subparsers(
        title='commands',
        required=True,
    )

    create_parser = maincmd_parsers.add_parser(
        'create',
        aliases=('c',),
        help='creates a minimal OCM Component Descriptor',
    )
    create_parser.add_argument('--name', default=None)
    create_parser.add_argument('--version', default=None)
    create_parser.add_argument('--provider', default=None)
    create_parser.add_argument('--ocm-repository')
    create_parser.add_argument('--label', dest='labels', action='append', default=[])
    create_parser.add_argument('--out', '-o', default='-')
    create_parser.set_defaults(callable=create)

    add_parser = maincmd_parsers.add_parser(
        'append',
        aliases=('a',),
        help='appends resources, sources, or component-references to component-descriptor',
    )
    add_parser.add_argument(
        'type',
        choices=(
            'r', 'resource',
            's', 'source',
            'c', 'component-reference',
            'l', 'component-label',
        )
    )
    add_parser.add_argument('--file', '-f', required=True)
    add_parser.add_argument(
        '--label',
        dest='labels',
        action='append',
        default=[],
        help='labels to set for passed artefact (for convenience)',
    )
    add_parser.set_defaults(callable=append)

    upload_parser = maincmd_parsers.add_parser(
        'upload',
        aliases=('u',),
        help='uploads a component-descriptor to an OCI-Registry',
    )
    upload_parser.add_argument('--file', '-f', required=True)
    upload_parser.add_argument(
        '--blobs-dir',
        required=False,
        help='optional path to lookup local-blobs. fnames must equal sha256-hexdigest',
    )
    upload_parser.add_argument('--ocm-repository', default=None)
    upload_parser.add_argument(
        '--on-exist',
        type=ocm.upload.UploadMode,
        default=ocm.upload.UploadMode.SKIP,
    )
    upload_parser.set_defaults(callable=upload)

    download_parser = maincmd_parsers.add_parser(
        'download',
        aliases=('d',),
    )
    download_parser.add_argument(
        'type',
        choices=(
            'component-descriptor', 'c',
            'source', 's',
            'resource', 'r',
        ),
    )
    download_parser.add_argument(
        '--component', '-c',
        required=True,
        help='component: <component>:<version>',
    )
    download_parser.add_argument(
        '--ocm-repository', '-O',
        required=True,
    )
    download_parser.add_argument(
        '--name',
    )
    download_parser.add_argument(
        '--id',
        dest='artefact_ids',
        help='artefact-id - format: --id <attr-name>=<value>',
        action='append',
        default=[],
    )
    download_parser.add_argument(
        '--outfile', '-o',
        default='-',
    )
    download_parser.add_argument(
        '--recursive',
        action='store_true',
    )
    download_parser.set_defaults(callable=download)

    replicate_parser = maincmd_parsers.add_parser(
        'replicate',
        aliases=('r',),
    )
    replicate_parser.set_defaults(callable=replicate)
    ctt.__main__.configure_parser(replicate_parser)

    replicate_cfg_parser = maincmd_parsers.add_parser(
        'generate-replication-cfg',
        aliases=('simple-cfg',),
    )
    replicate_cfg_parser.set_defaults(callable=generate_config)
    replicate_cfg_parser.add_argument('params', nargs='*')

    traverse_parser = maincmd_parsers.add_parser(
        'traverse',
        aliases=('t',),
    )
    traverse_parser.set_defaults(callable=_traverse)
    traverse_parser.add_argument(
        '--name',
        help='OCM-Component-Name and Version (<name>:<version>)',
        required=True,
    )
    traverse_parser.add_argument('--ocm-repository', required=True)
    traverse_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )
    traverse_parser.add_argument(
        '--node-kinds',
        default='crs',
        help='''\
            which nodes to include: (c)omponents, (r)esources, (s)ources; applied before
            evaluating --filter-expr
            ''',
    )
    traverse_parser.add_argument(
        '--format',
        choices=(
            'pretty',
            'json',
            'yaml',
        ),
        default='pretty',
    )
    traverse_parser.add_argument(
        '--print-expr',
        help='a python-expression that will be used to print nodes',
    )
    traverse_parser.add_argument(
        '--filter-expr',
        help='a python-expression used to filter nodes (omit node if evaluates to False)'
    )
    traverse_parser.add_argument(
        '--recursive',
        action='store_true',
        default=True,
        help='if set, will process subcomponents recursively',
    )
    traverse_parser.add_argument(
        '--no-recursive',
        action='store_false',
        default=True,
        dest='recursive',
        help='if set, will not process all subcomponents recursively',
    )

    imgvector_cfg_parser = maincmd_parsers.add_parser(
        'image-vector',
        aliases=('i',),
    )
    imgvector_cfg_parser.set_defaults(callable=imagevector)
    imgvector_cfg_parser.add_argument(
        '--name',
        help='OCM-Component-Version (<name>:<version>) (required if not using --recursive)',
        required=False,
    )
    imgvector_cfg_parser.add_argument(
        '--filter-expr',
        help=textwrap.dedent('''\
        a python-expression to filter componentversions (only used if --recursive)
        in scope: `component` (ocm.Component) and `node` (ocm.iter.ComponentNode)
        True: include componentversion
        False: exclude componentversion
        '''),
        required=False,
        default=None,
    )
    imgvector_cfg_parser.add_argument(
        '--recursive',
        action='store_true',
        default=False,
        help='if set, will yield imagevector for all subcomponents recursively',
    )
    imgvector_cfg_parser.add_argument(
        '--root-name',
        help='OCM-Root-Component-Name and Version (<name>:<version>)',
        required=True,
    )
    imgvector_cfg_parser.add_argument('--ocm-repository', required=True)
    imgvector_cfg_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )
    imgvector_cfg_parser.add_argument(
        '--select-images',
        choices=('by-label', 'all'),
        default='by-label',
    )
    imgvector_cfg_parser.add_argument(
        '--subcomponent-ref-name',
        required=False,
        default=None,
        help='if set, resolve the named componentReference and wrap output as component overwrite',
    )

    helmvalues_parser = maincmd_parsers.add_parser(
        'helm-values',
        aliases=('hv',),
        help='generates localised helm-values',
    )
    helmvalues_parser.add_argument(
        '--component', '-c',
        required=True,
        help='component: <component>:<version>',
    )
    helmvalues_parser.add_argument(
        '--ocm-repository', '-O',
        required=True,
    )
    helmvalues_parser.add_argument(
        '--resource',
        required=True,
        help='identifies the helmchart - either <resource-name> or <resource-name>:<version>',
    )
    helmvalues_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )
    helmvalues_parser.set_defaults(callable=helm_values)

    normalise_parser = maincmd_parsers.add_parser(
        'normalise',
        aliases=('n',),
        help='print normalised component-descriptor (for signature-validation and signing)',
    )
    normalise_parser.set_defaults(callable=normalise)
    normalise_parser.add_argument(
        '--ocm-repository',
        required=True,
    )
    normalise_parser.add_argument(
        '--name',
        help='OCM-Component-Name and Version (<name>:<version>)',
        required=True,
    )
    normalise_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )
    normalise_parser.add_argument(
        '--validate-digests',
        dest='validate_digests', # explicit is (in this case, specifically) better than implicit
        action='store_true',
        default=True,
        required=False,
    )
    normalise_parser.add_argument(
        '--no-validate-digests',
        dest='validate_digests',
        action='store_false',
        default=True,
        required=False,
    )

    validate_parser = maincmd_parsers.add_parser(
        'validate',
        aliases=('v',),
        help='validates signature of a component-descriptor',
    )
    validate_parser.set_defaults(callable=validate)
    validate_parser.add_argument(
        '--ocm-repository',
        required=True,
    )
    validate_parser.add_argument(
        '--name',
        help='OCM-Component-Name and Version (<name>:<version>)',
        required=True,
    )
    validate_parser.add_argument(
        '--validate-digests',
        dest='validate_digests', # explicit is (in this case, specifically) better than implicit
        action='store_true',
        default=True,
        required=False,
    )
    validate_parser.add_argument(
        '--no-validate-digests',
        dest='validate_digests',
        action='store_false',
        default=True,
        required=False,
    )
    # todo: allow passing normalised component-descriptor from filesystem as alternative to
    #       retrieving from OCM-Repository
    validate_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )
    validate_parser.add_argument(
        '--ca-file',
        required=True,
        help='path to certificate(s) to trust (expected in PEM-format)',
    )

    edit_parser = maincmd_parsers.add_parser(
        'edit',
        aliases=('e',),
        help='interactively edit a component-descriptor stored in an OCI registry',
    )
    edit_parser.set_defaults(callable=edit)
    edit_parser.add_argument(
        '--component', '-c',
        required=True,
        help='component: <component-name>:<version>',
    )
    edit_parser.add_argument(
        '--ocm-repository', '-O',
        required=True,
    )
    edit_parser.add_argument(
        '--editor',
        default='vim',
        help='editor command to invoke (default: vim)',
    )
    edit_parser.add_argument(
        '--docker-cfg',
        required=False,
        help='path to dockerd\'s `config.json` file',
    )

    prune_parser = maincmd_parsers.add_parser(
        'prune',
        aliases=('p',),
        help='prune stale OCI artefacts from target registries',
    )

    def _prune(parsed):
        oci_client = oci.client.Client(
            credentials_lookup=oci.auth.docker_credentials_lookup(
                docker_cfg=parsed.docker_cfg,
            ),
            max_retries=parsed.retries,
        )
        ocm_repo = ocm.OciOcmRepository(
            type=ocm.OciAccess,
            baseUrl=parsed.ocm_repo,
        )
        mode = ocm.prune.EnumerationMode(0)
        if not parsed.full_registry:
            mode |= ocm.prune.EnumerationMode.KNOWN_REPOSITORIES
        if parsed.restrict_to_ocm_repo:
            mode |= ocm.prune.EnumerationMode.RESTRICT_TO_OCM_REPO

        ctx = ocm.prune.PruneCtx(ocm_repo=ocm_repo, oci_client=oci_client, mode=mode)

        print(f'Building retain set from {len(parsed.ocm_component)} root component(s)...')
        for component_ref in parsed.ocm_component:
            name, anchor = ocm.prune.parse_component_ref(component_ref)
            for ver in ocm.prune.resolve_versions(
                name, anchor, ocm_repo, oci_client, parsed.keep_versions,
            ):
                ocm.prune.prune(ocm.ComponentIdentity(name=name, version=ver), ctx)
        print(f'Retain set: {len(ctx.retain_set)} OCI reference(s)')

        if parsed.retained_outfile:
            with open(parsed.retained_outfile, 'w') as fh:
                for ref in sorted(ctx.retain_set):
                    fh.write(ref + '\n')
            print(f'Retain set written to {parsed.retained_outfile!r}')

        print('Enumerating candidates...')
        ocm.prune.enumerate_candidates(ctx, jobs=parsed.jobs)
        to_delete = ctx.candidates - ctx.retain_set
        print(f'Found {len(to_delete)} candidate(s) to prune')

        if parsed.candidates_outfile:
            with open(parsed.candidates_outfile, 'w') as fh:
                for ref in sorted(to_delete):
                    fh.write(ref + '\n')
            print(f'Candidate list written to {parsed.candidates_outfile!r}')

        if parsed.dry_run:
            print('Dry run — nothing removed')
            for ref in sorted(to_delete):
                print(f'  would remove: {ref}')
            return

        ocm.prune.delete_all(to_delete, oci_client, jobs=parsed.jobs)
        print(f'Pruned {len(to_delete)} artefact(s)')

    prune_parser.set_defaults(callable=_prune)
    prune_parser.add_argument(
        '--ocm-repo', '-O',
        required=True,
        help='OCM repository base URL (target registry)',
    )
    prune_parser.add_argument(
        '--ocm-component', '-c',
        required=True,
        action='append',
        dest='ocm_component',
        metavar='NAME[:VERSION]',
        help=(
            'root component to retain (repeatable); '
            'omit version to use the greatest available'
        ),
    )
    prune_parser.add_argument(
        '--keep-versions',
        type=int,
        default=1,
        metavar='N',
        help=(
            'number of versions to retain per root component '
            '(anchor + N-1 next-older); default: 1'
        ),
    )
    prune_parser.add_argument(
        '--full-registry',
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            'enumerate all repositories via vendor API (Keppel/GAR); '
            'default: inspect only repositories referenced by the retain set'
        ),
    )
    prune_parser.add_argument(
        '--restrict-to-ocm-repo',
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            'skip OCI resource refs outside the target OCM repository prefix; '
            'default: true'
        ),
    )
    prune_parser.add_argument(
        '--dry-run',
        action='store_true',
        default=False,
        help='print candidates without removing anything',
    )
    prune_parser.add_argument(
        '--retained-outfile',
        metavar='FILE',
        default=None,
        help='write the retain set to FILE (one reference per line)',
    )
    prune_parser.add_argument(
        '--candidates-outfile',
        metavar='FILE',
        default=None,
        help='write the candidate list to FILE (one reference per line)',
    )
    prune_parser.add_argument(
        '--retries',
        type=int,
        default=5,
        metavar='N',
        help='OCI request retry count (default: 5)',
    )
    prune_parser.add_argument(
        '--jobs', '-j',
        type=int,
        default=8,
        metavar='N',
        help='parallelism for tag listing and deletion (default: 8)',
    )
    prune_parser.add_argument(
        '--docker-cfg',
        default=None,
        help='path to dockerd\'s `config.json` file',
    )

    if len(sys.argv) < 2:
        parser.print_usage()
        exit(0)

    parsed = parser.parse_args()

    parsed.callable(parsed)


if __name__ == '__main__':
    main()
