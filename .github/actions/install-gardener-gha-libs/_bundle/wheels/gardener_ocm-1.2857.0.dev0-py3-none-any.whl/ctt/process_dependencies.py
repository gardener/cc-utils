# SPDX-FileCopyrightText: Contributors to the Gardener project
#
# SPDX-License-Identifier: Apache-2.0

import collections
import collections.abc
import concurrent.futures
import copy
import dataclasses
import enum
import hashlib
import functools
import itertools
import json
import jsonschema
import logging
import os
import requests
import threading
import tempfile
import urllib.parse

import dacite
import yaml

import ocm.retrieve
import ctt.oci_util
import ctt.replicate
import sbom.cbom as sbom_cbom
import sbom.inject as sbom_inject
import sbom.s3 as sbom_s3
import oci
import oci.client
import oci.model as om
import oci.workarounds
import ocm
import ocm.gardener
import ocm.iter

import ctt.filters as filters
import ctt.model
import ctt.processors as processors
import ctt.targets as targets
import ctt.uploaders as uploaders
import ctt.util as ctt_util

original_tag_label_name = 'cloud.gardener.cnudie/migration/original_tag'

logger = logging.getLogger(__name__)

own_dir = os.path.abspath(os.path.dirname(__file__))


class ProcessingMode(enum.Enum):
    REGULAR = 'regular'
    DRY_RUN = 'dry_run'


class PruningMode(enum.StrEnum):
    '''
    Controls tree-pruning behaviour during replication.

    CTT replicates component trees bottom-up: resources (OCI images) first, then the
    OCM component descriptor as a marker that all resources for that component are present.
    Tree-pruning exploits this invariant top-down: starting from the root component it skips
    any subtree whose root descriptor already exists in the target, avoiding redundant work.
    This optimisation is robust in the common case but may miss partial replications in
    corner-cases; use REPLICATE_ALL for a full replication at the cost of extra HEAD requests.

    FORCE_OVERWRITE_DESCRIPTORS behaves like REPLICATE_ALL for tree-traversal but additionally
    overwrites component-descriptors even when they already exist in the target.  OCI artefacts
    are still skipped when already present.  Useful when descriptor content must be refreshed
    (e.g. after a reference-rewrite rule change) without re-pushing all images.
    '''
    PRUNE_SUBTREES = 'prune-subtrees'  # skip subtrees whose root descriptor exists in target
    REPLICATE_ALL = 'replicate-all'    # replicate full transitive closure unconditionally
    FORCE_OVERWRITE_DESCRIPTORS = 'force-overwrite-descriptors'  # overwrite descriptors, skip images


class LocalBlobsMode(enum.StrEnum):
    '''
    Controls how local blobs (inlined into the component descriptor OCI artifact as layers) are
    handled when replicating to a target registry.

    COPY_BY_VALUE (default): replicate blob data as layers into the target manifest.
    COPY_BY_REFERENCE: omit local blob layers from the target manifest and instead populate
        globalAccess on each LocalBlobAccess resource, pointing back to the source artifact.
        Use this for registries that impose a layer limit (e.g. AWS ECR).
    '''
    COPY_BY_VALUE = 'copy_by_value'
    COPY_BY_REFERENCE = 'copy_by_reference'


@functools.cache
def create_component_descriptor_lookup_for_ocm_repo(
    ocm_repo_url: str,
    oci_client: oci.client.Client | None=None,
) -> ocm.retrieve.ComponentDescriptorLookupById:
    return ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(ocm_repo_url),
        oci_client=oci_client,
    )


class ProcessingPipeline:
    def __init__(
        self,
        name: str,
        targets: list[targets.TargetBase],
        filters: list[filters.FilterBase],
        processor: processors.ProcessorBase,
        uploaders: list[uploaders.UploaderBase],
        inject_sboms: bool=False,
    ):
        self._name = name
        self._targets = targets
        self._filters = filters
        self._processor = processor
        self._uploaders = uploaders
        self._inject_sboms = inject_sboms

    def matches_filter(
        self,
        component: ocm.Component,
        resource: ocm.Resource,
    ) -> bool:
        return all(
            filter.matches(component, resource)
            for filter in self._filters
        )

    def matching_registries(
        self,
        tgt_oci_registries: collections.abc.Iterable[str],
    ) -> collections.abc.Iterable[str]:
        for tgt_oci_registry in tgt_oci_registries:
            for target in self._targets:
                if target.filter(tgt_oci_registry):
                    yield tgt_oci_registry

    def process(
        self,
        component: ocm.Component,
        resource: ocm.Resource,
        tgt_oci_registries: collections.abc.Iterable[str],
        oci_client: oci.client.Client,
        replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    ) -> ctt.model.ReplicationResourceElement | None:
        if not self.matches_filter(component, resource):
            return None

        matching_tgt_oci_registries = list(self.matching_registries(tgt_oci_registries))
        if len(matching_tgt_oci_registries) == 0:
            return None
        elif len(matching_tgt_oci_registries) > 1:
            raise RuntimeError(
                f'image processing pipeline {self._name} contains multiple targets with the same '
                'OCM repository, this likely indicates a wrong replication-cfg '
                f'({matching_tgt_oci_registries=})'
            )
        else:
            tgt_oci_registry = matching_tgt_oci_registries[0]

        logger.debug(
            f'{self._name} will process: {component.name}:{resource.type}:{resource.access} '
            f'{tgt_oci_registry=}'
        )

        # create copies to not unintentionally modify mutually/afterwards
        replication_resource_element = ctt.model.ReplicationResourceElement(
            source=copy.deepcopy(resource),
            target=copy.deepcopy(resource),
            component_id=component.identity(),
            src_ocm_repo=component.current_ocm_repo,
        )

        replication_resource_element = self._processor.process(replication_resource_element)

        first = True
        for uploader in self._uploaders:
            replication_resource_element = uploader.process(
                replication_resource_element,
                tgt_oci_registry=tgt_oci_registry,
                target_as_source=not first,
            )
            first = False

        if self._inject_sboms:
            replication_resource_element.inject_sboms = True

        ctt_label = create_ctt_label(
            processing_rules=[
                self._name,
            ],
        )
        replication_resource_element.target.set_label(
            label=ctt_label,
        )

        if manifest_blob_ref := oci_client.head_manifest(
            image_reference=str(replication_resource_element.tgt_ref),
            absent_ok=True,
            accept=replication_mode.accept_header(),
        ):
            replication_resource_element.digest = manifest_blob_ref.digest

        return replication_resource_element


def create_ctt_label(
    processing_rules: list[str],
) -> ocm.Label:
    ctt_label_name = 'cloud.gardener/ctt-hint'
    label = ocm.Label(
        name=ctt_label_name,
        value={
            'processingRules': processing_rules,
        },
    )

    return label


def parse_processing_cfg(path: str):
    with open(path) as f:
        raw_cfg = yaml.safe_load(f)

    processing_cfg_dir = os.path.abspath(os.path.dirname(path))
    for _, cfg in raw_cfg.get('processors', {}).items():
        kwargs = cfg.get('kwargs', {})
        kwargs['base_dir'] = processing_cfg_dir

    return raw_cfg


_TARGET_ONLY_KWARGS = {'local_blobs', 'max_concurrency'}


def _target(target_cfg: dict):
    target_type = target_cfg['type']
    target_ctor = getattr(targets, target_type, None)
    if not target_ctor:
        logger.critical(f'no such target: {target_type}')
        exit(1)
    kwargs = {k: v for k, v in target_cfg.get('kwargs', {}).items()
              if k not in _TARGET_ONLY_KWARGS}
    target = target_ctor(**kwargs)
    return target


def _filter(filter_cfg: dict):
    filter_ctor = getattr(filters, filter_cfg['type'])
    filter_ = filter_ctor(**filter_cfg.get('kwargs', {}))

    return filter_


def _processor(processor_cfg: dict):
    proc_type = processor_cfg['type']
    proc_ctor = getattr(processors, proc_type, None)
    if not proc_ctor:
        logger.critical(f'no such image processor: {proc_type}')
        exit(1)
    processor = proc_ctor(**processor_cfg.get('kwargs', {}))
    return processor


def _uploader(uploader_cfg: dict):
    upload_type = uploader_cfg['type']
    upload_ctor = getattr(uploaders, upload_type, None)
    if not upload_ctor:
        logger.critical(f'no such uploader: {upload_type}')
        exit(1)
    uploader = upload_ctor(**uploader_cfg.get('kwargs', {}))
    return uploader


def processing_pipeline(
    processing_cfg: dict,
    shared_targets: dict={},
    shared_processors: dict={},
    shared_uploaders: dict={},
) -> ProcessingPipeline:
    name = processing_cfg.get('name', '<no name>')

    target_cfgs = processing_cfg['target']
    if not isinstance(target_cfgs, list):
        target_cfgs = [target_cfgs]

    def instantiate_target(target_cfg):
        if isinstance(target_cfg, str):
            return shared_targets[target_cfg]
        return _target(target_cfg)

    targets = [instantiate_target(target_cfg) for target_cfg in target_cfgs]

    filter_cfgs = processing_cfg['filter']
    if isinstance(filter_cfgs, dict):
        filter_cfgs = [filter_cfgs]
    filters = [_filter(filter_cfg=filter_cfg) for filter_cfg in filter_cfgs]

    if 'processor' in processing_cfg:
        processor_cfg = processing_cfg['processor']
        if isinstance(processor_cfg, str):
            proc = shared_processors[processor_cfg]
        else:
            proc = _processor(processor_cfg=processor_cfg)
    else:
        proc = processors.NoOpProcessor()

    upload_cfgs = processing_cfg['upload']
    if not isinstance(upload_cfgs, list):
        upload_cfgs = [upload_cfgs]  # normalise to list

    def instantiate_uploader(upload_cfg):
        if isinstance(upload_cfg, str):
            return shared_uploaders[upload_cfg]
        return _uploader(upload_cfg)

    uploaders = [instantiate_uploader(upload_cfg) for upload_cfg in upload_cfgs]

    inject_sboms = bool(processing_cfg.get('inject_sboms', False))

    pipeline = ProcessingPipeline(
        name=name,
        targets=targets,
        filters=filters,
        processor=proc,
        uploaders=uploaders,
        inject_sboms=inject_sboms,
    )
    return pipeline


def enum_processing_cfgs(
    processing_cfg: dict,
    shared_targets: dict,
    shared_processors: dict,
    shared_uploaders: dict,
):
    cfg_entries = processing_cfg['image_processing_cfg']

    yield from map(
        processing_pipeline,
        cfg_entries,
        itertools.repeat(shared_targets, len(cfg_entries)),
        itertools.repeat(shared_processors, len(cfg_entries)),
        itertools.repeat(shared_uploaders, len(cfg_entries)),
    )


def determine_changed_components(
    component_descriptor: ocm.ComponentDescriptor,
    tgt_ocm_repo_url: str,
    component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    tgt_component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    component_filter: collections.abc.Callable[[ocm.Component], bool]=None,
    reftype_filter: collections.abc.Callable[[ocm.iter.NodeReferenceType], bool]=None,
    pruning_mode: PruningMode=PruningMode.PRUNE_SUBTREES,
    _visited: set[ocm.ComponentIdentity] | None=None,
) -> collections.abc.Generator[ocm.ComponentDescriptor, None, None]:
    component = component_descriptor.component

    # the component-reference graph is not necessarily a tree (diamond dependencies, where the
    # same component is referenced via more than one path, are common) - without this guard, a
    # shared component would be yielded once per path leading to it, which in turn causes its
    # resources (e.g. injected SBOM/CBOM resources) to be processed - and appended - more than
    # once downstream, resulting in duplicate OCM resource identities.
    if _visited is None:
        _visited = set()
    if component.identity() in _visited:
        return
    _visited.add(component.identity())

    if component_filter and component_filter(component):
        return

    if (
        pruning_mode is PruningMode.PRUNE_SUBTREES
        and tgt_component_descriptor_lookup(
            component.identity(),
            absent_ok=True,
        )
    ):
        logger.info(
            f'{component.identity()} already exists in {tgt_ocm_repo_url=} '
            '- skipping replication of transitive closure'
        )
        return

    for cref in component.componentReferences:
        referenced_component_descriptor = component_descriptor_lookup(ocm.ComponentIdentity(
            name=cref.componentName,
            version=cref.version,
        ))

        yield from determine_changed_components(
            component_descriptor=referenced_component_descriptor,
            tgt_ocm_repo_url=tgt_ocm_repo_url,
            component_descriptor_lookup=component_descriptor_lookup,
            tgt_component_descriptor_lookup=tgt_component_descriptor_lookup,
            component_filter=component_filter,
            reftype_filter=reftype_filter,
            pruning_mode=pruning_mode,
            _visited=_visited,
        )

    if not (
        reftype_filter and reftype_filter(ocm.iter.NodeReferenceType.EXTRA_COMPONENT_REFS_LABEL)
    ) and (
        extra_crefs_label := component.find_label(ocm.gardener.ExtraComponentReferencesLabel.name)
    ):
        for extra_cref_raw in extra_crefs_label.value:
            extra_cref = dacite.from_dict(
                data_class=ocm.gardener.ExtraComponentReference,
                data=extra_cref_raw,
            )
            extra_cref_id = extra_cref.component_reference
            referenced_component_descriptor = component_descriptor_lookup(extra_cref_id)

            yield from determine_changed_components(
                component_descriptor=referenced_component_descriptor,
                tgt_ocm_repo_url=tgt_ocm_repo_url,
                component_descriptor_lookup=component_descriptor_lookup,
                tgt_component_descriptor_lookup=tgt_component_descriptor_lookup,
                component_filter=component_filter,
                reftype_filter=reftype_filter,
                pruning_mode=pruning_mode,
                _visited=_visited,
            )

    yield component_descriptor


uploaded_image_refs_to_digests = {}  # <ref>:<digest>
uploaded_image_refs_to_ready_events = {}  # <ref>:<event> (set if digest is available)
upload_image_lock = threading.Lock()


# uploads a single OCI artifact and returns the content digest
def process_upload_request(
    replication_resource_element: ctt.model.ReplicationResourceElement,
    oci_client: oci.client.Client,
    replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    platform_filter: collections.abc.Callable[[om.OciPlatform], bool]=None,
    inject_ocm_coordinates_into_oci_manifests: bool=False,
    processing_mode: ProcessingMode=ProcessingMode.REGULAR,
) -> str:
    src_ref = replication_resource_element.src_ref
    tgt_ref = replication_resource_element.tgt_ref

    if replication_resource_element.digest:
        logger.debug(f'{tgt_ref=} exists - skipping upload')
        return replication_resource_element.digest

    # if event is present, upload might still be in progress (done if event is "set")
    with upload_image_lock:
        if tgt_ref in uploaded_image_refs_to_ready_events:
            upload_done_event = uploaded_image_refs_to_ready_events[tgt_ref]
            wait_for_upload = True
        else:
            upload_done_event = threading.Event()
            uploaded_image_refs_to_ready_events[tgt_ref] = upload_done_event
            wait_for_upload = False

    if wait_for_upload:
        upload_done_event.wait()

    if tgt_ref in uploaded_image_refs_to_digests:  # digest already present
        logger.info(f'{tgt_ref=} - was already uploaded by another rule - skipping')
        return uploaded_image_refs_to_digests[tgt_ref]

    # most common case: tgt has not yet been processed - process and afterwards signal
    # other threads waiting for upload result that result is ready by setting the event

    remove_files = replication_resource_element.remove_files
    component = replication_resource_element.component_id
    resource = replication_resource_element.target

    logger.info(
        f'processing {src_ref=} -> {tgt_ref=} {remove_files=} {replication_mode=} {platform_filter=}'
    )

    if inject_ocm_coordinates_into_oci_manifests:
        oci_manifest_annotations = {
            'cloud.gardener/ocm-component': f'{component.name}:{component.version}',
            'cloud.gardener/ocm-resource': f'{resource.name}:{resource.version}',
        }
    else:
        oci_manifest_annotations = None

    logger.debug(f'{oci_manifest_annotations=}')

    if processing_mode is ProcessingMode.DRY_RUN:
        manifest_digest = '<dummy-digest>'
        uploaded_image_refs_to_digests[tgt_ref] = f'sha256:{manifest_digest}'
        upload_done_event.set()
        return f'sha256:{manifest_digest}'

    try:
        _, patched_tgt_ref, raw_manifest = ctt.oci_util.filter_image(
            source_ref=src_ref,
            target_ref=tgt_ref,
            remove_files=remove_files,
            mode=replication_mode,
            platform_filter=platform_filter,
            oci_client=oci_client,
            oci_manifest_annotations=oci_manifest_annotations,
        )
    except Exception as e:
        logger.error(
            f'error trying to replicate {src_ref=} -> {tgt_ref=}'
        )
        e.add_note(f'filter_image: {src_ref=} -> {tgt_ref=}')
        raise e

    if tgt_ref != patched_tgt_ref:
        logger.info(f'finished processing {src_ref=} -> {patched_tgt_ref=} (initial {tgt_ref=})')
    else:
        logger.info(f'finished processing {src_ref=} -> {tgt_ref=}')

    manifest_digest = hashlib.sha256(raw_manifest).hexdigest()
    uploaded_image_refs_to_digests[tgt_ref] = f'sha256:{manifest_digest}'
    upload_done_event.set()
    return f'sha256:{manifest_digest}'


def iter_replication_plan_components(
    component_descriptors: collections.abc.Iterable[ocm.ComponentDescriptor],
    tgt_ocm_repo: ocm.OciOcmRepository,
    remove_label: collections.abc.Callable[[str], bool] | None=None,
) -> collections.abc.Iterable[ctt.model.ReplicationComponentElement]:
    for component_descriptor in component_descriptors:
        # create copy to not unintentionally modify mutually/afterwards (e.g. relevant for in-memory
        # lookup)
        source = copy.deepcopy(component_descriptor)
        target = copy.deepcopy(component_descriptor)

        target.component.set_current_ocm_repo(tgt_ocm_repo)

        if remove_label:
            target.component.labels = [
                label for label in target.component.labels
                if not remove_label(label.name)
            ]

        yield ctt.model.ReplicationComponentElement(
            source=source,
            target=target,
        )


def iter_replication_resource_elements(
    component_descriptors: collections.abc.Iterable[ocm.ComponentDescriptor],
    processing_cfg: dict,
    tgt_oci_registries: collections.abc.Sequence[str],
    oci_client: oci.client.Client,
    replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    max_workers: int=16,
) -> collections.abc.Iterable[ctt.model.ReplicationResourceElement]:
    shared_targets = {
        name: _target(cfg) for name, cfg in processing_cfg.get('targets', {}).items()
    }
    shared_processors = {
        name: _processor(cfg) for name, cfg in processing_cfg.get('processors', {}).items()
    }
    shared_uploaders = {
        name: _uploader(cfg) for name, cfg in processing_cfg.get('uploaders', {}).items()
    }

    def create_replication_resource_element(
        component: ocm.Component,
        resource: ocm.Resource,
    ) -> ctt.model.ReplicationResourceElement | None:
        for pipeline in enum_processing_cfgs(
            processing_cfg=processing_cfg,
            shared_targets=shared_targets,
            shared_processors=shared_processors,
            shared_uploaders=shared_uploaders,
        ):
            replication_resource_element = pipeline.process(
                component=component,
                resource=resource,
                tgt_oci_registries=tgt_oci_registries,
                oci_client=oci_client,
                replication_mode=replication_mode,
            )

            if replication_resource_element:
                return replication_resource_element

        logger.debug(
            f'skipped processing: {component.name}:{resource.access} ({tgt_oci_registries=})'
        )

    components_with_resource = [
        (component_descriptor.component, resource)
        for component_descriptor in component_descriptors
        for resource in component_descriptor.component.resources
        if resource.access.type in (
            ocm.AccessType.OCI_REGISTRY,
            ocm.AccessType.RELATIVE_OCI_REFERENCE,
        )
    ]

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
    yield from (
        replication_resource_element for replication_resource_element in executor.map(
            create_replication_resource_element,
            [component for component, _ in components_with_resource],
            [resource for _, resource in components_with_resource],
        ) if replication_resource_element
    )


def create_replication_plan_step(
    processing_cfg: dict,
    root_component_descriptor: ocm.ComponentDescriptor,
    src_component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    tgt_component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    ocm_repository: str,
    tgt_oci_registries: collections.abc.Sequence[str],
    oci_client: oci.client.Client,
    replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    component_filter: collections.abc.Callable[[ocm.Component], bool] | None=None,
    reftype_filter: collections.abc.Callable[[ocm.iter.NodeReferenceType], bool] | None=None,
    remove_label: collections.abc.Callable[[str], bool]=None,
    max_workers: int=16,
    pruning_mode: PruningMode=PruningMode.PRUNE_SUBTREES,
) -> ctt.model.ReplicationPlanStep:
    tgt_ocm_repo = ocm.OciOcmRepository(
        baseUrl=ocm_repository,
    )

    component_descriptors = tuple(determine_changed_components(
        component_descriptor=root_component_descriptor,
        tgt_ocm_repo_url=ocm_repository,
        component_descriptor_lookup=src_component_descriptor_lookup,
        tgt_component_descriptor_lookup=tgt_component_descriptor_lookup,
        component_filter=component_filter,
        reftype_filter=reftype_filter,
        pruning_mode=pruning_mode,
    ))

    components = tuple(iter_replication_plan_components(
        component_descriptors=component_descriptors,
        tgt_ocm_repo=tgt_ocm_repo,
        remove_label=remove_label,
    ))

    resources = tuple(iter_replication_resource_elements(
        component_descriptors=component_descriptors,
        processing_cfg=processing_cfg,
        tgt_oci_registries=tgt_oci_registries,
        oci_client=oci_client,
        replication_mode=replication_mode,
        max_workers=max_workers,
    ))

    return ctt.model.ReplicationPlanStep(
        target_ocm_repository=ocm_repository,
        resources=resources,
        components=components,
    )


def process_images(
    processing_cfg_path: str,
    root_component_descriptor: ocm.ComponentDescriptor,
    component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    oci_client: oci.client.Client,
    processing_mode: ProcessingMode=ProcessingMode.REGULAR,
    replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    inject_ocm_coordinates_into_oci_manifests: bool=False,
    skip_cd_validation: bool=False,
    platform_filter: collections.abc.Callable[[om.OciPlatform], bool]=None,
    skip_component_upload: collections.abc.Callable[[ocm.Component], bool]=None,
    component_filter: collections.abc.Callable[[ocm.Component], bool]=None,
    remove_label: collections.abc.Callable[[str], bool]=None,
    max_workers: int=16,
    tgt_ocm_repo_path: str | None=None, # deprecated -> specify `ocm_repository` in tgt-cfg instead
    pruning_mode: PruningMode=PruningMode.PRUNE_SUBTREES,
    inject_s3_sboms: bool=False,
    paranoid: bool=False,
) -> collections.abc.Generator[ocm.iter.Node, None, None]:
    '''
    note: Passing a filter to prevent component descriptors from being replicated using the
    `skip_component_upload` parameter will still replicate all its resources (i.e. oci images)
    as well as referenced components. In contrast to that, passing a filter using the
    `component_filter` parameter will also exclude its resources as well as all transitive component
    references from the replication. In both cases, `True` means the respective component is
    _excluded_.
    '''
    processing_cfg = parse_processing_cfg(processing_cfg_path)

    if paranoid:
        oci.workarounds.patch_put_manifest_to_validate_via_get(oci_client)

    reftype_filter = None
    if remove_label and remove_label(ocm.gardener.ExtraComponentReferencesLabel.name):
        def filter_extra_component_refs(reftype: ocm.iter.NodeReferenceType) -> bool:
            return reftype is ocm.iter.NodeReferenceType.EXTRA_COMPONENT_REFS_LABEL

        reftype_filter = filter_extra_component_refs

    if processing_mode is ProcessingMode.DRY_RUN:
        logger.warning('dry-run: not downloading or uploading any images')

    registries_by_ocm_repository: dict[str, set[str]] = collections.defaultdict(set)
    local_blobs_by_ocm_repository: dict[str, LocalBlobsMode] = {}

    for target_cfg in processing_cfg['targets'].values():
        target_cfg = target_cfg['kwargs']

        if registry := target_cfg.get('registry'):
            registries = [registry]
        else:
            registries = target_cfg.get('registries', [])

        if not (ocm_repository := target_cfg.get('ocm_repository')):
            if not tgt_ocm_repo_path:
                raise ValueError(
                    'in case `ocm_repository` is not specified in the target configuration, '
                    '`tgt_ocm_repo_path` must be passed explicitly'
                )
            if len(registries) != 1:
                raise ValueError(
                    'in case `ocm_repository` is not specified in the target configuration, only a '
                    'single registry is allowed'
                )
            ocm_repository = '/'.join((
                registries[0].rstrip('/'),
                tgt_ocm_repo_path.lstrip('/'),
            ))

        registries_by_ocm_repository[ocm_repository].update(registries)
        local_blobs_by_ocm_repository[ocm_repository] = LocalBlobsMode(
            target_cfg.get('local_blobs', LocalBlobsMode.COPY_BY_VALUE)
        )

        if max_concurrency := target_cfg.get('max_concurrency'):
            for reg in registries:
                host = urllib.parse.urlparse(f'//{reg}').netloc
                oci_client.set_host_initial_limit(host, int(max_concurrency))
                logger.info(f'per-target max_concurrency for {host} set to {max_concurrency}')

    replication_plan = ctt.model.ReplicationPlan()

    for ocm_repository, tgt_oci_registries in registries_by_ocm_repository.items():
        tgt_component_descriptor_lookup = create_component_descriptor_lookup_for_ocm_repo(
            ocm_repo_url=ocm_repository,
            oci_client=oci_client,
        )

        replication_plan_step = create_replication_plan_step(
            processing_cfg=processing_cfg,
            root_component_descriptor=root_component_descriptor,
            src_component_descriptor_lookup=component_descriptor_lookup,
            tgt_component_descriptor_lookup=tgt_component_descriptor_lookup,
            ocm_repository=ocm_repository,
            tgt_oci_registries=list(tgt_oci_registries),
            oci_client=oci_client,
            replication_mode=replication_mode,
            component_filter=component_filter,
            reftype_filter=reftype_filter,
            remove_label=remove_label,
            max_workers=max_workers,
            pruning_mode=pruning_mode,
        )
        replication_plan.steps.append(replication_plan_step)

    logger.info(replication_plan)

    def _exec_step(step):
        tgt_lookup = create_component_descriptor_lookup_for_ocm_repo(
            ocm_repo_url=step.target_ocm_repository,
            oci_client=oci_client,
        )
        local_blobs_mode = local_blobs_by_ocm_repository.get(
            step.target_ocm_repository,
            LocalBlobsMode.COPY_BY_VALUE,
        )
        return list(process_replication_plan_step(
            replication_plan_step=step,
            root_component_descriptor=root_component_descriptor,
            oci_client=oci_client,
            tgt_component_descriptor_lookup=tgt_lookup,
            processing_mode=processing_mode,
            replication_mode=replication_mode,
            inject_ocm_coordinates_into_oci_manifests=inject_ocm_coordinates_into_oci_manifests,
            platform_filter=platform_filter,
            component_filter=component_filter,
            reftype_filter=reftype_filter,
            skip_cd_validation=skip_cd_validation,
            skip_component_upload=skip_component_upload,
            overwrite_descriptors=pruning_mode is PruningMode.FORCE_OVERWRITE_DESCRIPTORS,
            max_workers=max_workers,
            inject_s3_sboms=inject_s3_sboms,
            local_blobs_mode=local_blobs_mode,
        ))

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=len(replication_plan.steps),
    ) as step_executor:
        for nodes in step_executor.map(_exec_step, replication_plan.steps):
            yield from nodes


def process_replication_plan_step(
    replication_plan_step: ctt.model.ReplicationPlanStep,
    root_component_descriptor: ocm.ComponentDescriptor,
    oci_client: oci.client.Client,
    tgt_component_descriptor_lookup: ocm.retrieve.ComponentDescriptorLookupById,
    processing_mode: ProcessingMode=ProcessingMode.REGULAR,
    replication_mode: oci.ReplicationMode=oci.ReplicationMode.PREFER_MULTIARCH,
    inject_ocm_coordinates_into_oci_manifests: bool=False,
    platform_filter: collections.abc.Callable[[om.OciPlatform], bool]=None,
    component_filter: collections.abc.Callable[[ocm.Component], bool] | None=None,
    reftype_filter: collections.abc.Callable[[ocm.iter.NodeReferenceType], bool] | None=None,
    skip_cd_validation: bool=False,
    skip_component_upload: collections.abc.Callable[[ocm.Component], bool] | None=None,
    overwrite_descriptors: bool=False,
    max_workers: int=16,
    inject_s3_sboms: bool=False,
    local_blobs_mode: LocalBlobsMode=LocalBlobsMode.COPY_BY_VALUE,
) -> collections.abc.Generator[ocm.iter.Node, None, None]:
    def process_replication_resource_element(
        replication_resource_element: ctt.model.ReplicationResourceElement,
    ) -> ctt.model.ReplicationResourceElement:
        oci_manifest_digest = process_upload_request(
            replication_resource_element=replication_resource_element,
            oci_client=oci_client,
            replication_mode=replication_mode,
            platform_filter=platform_filter,
            inject_ocm_coordinates_into_oci_manifests=inject_ocm_coordinates_into_oci_manifests,
            processing_mode=processing_mode,
        )

        if not oci_manifest_digest:
            raise RuntimeError(f'No digest returned for {replication_resource_element=}')

        if (
            processing_mode is not ProcessingMode.DRY_RUN
            and (extra_tags := replication_resource_element.extra_tags)
        ):
            target_repo = replication_resource_element.tgt_ref.ref_without_tag
            manifest_bytes = oci_client.manifest_raw(
                image_reference=f'{target_repo}@{oci_manifest_digest}',
                accept=replication_mode.accept_header(),
            ).content

            for extra_tag in extra_tags:
                push_target = f'{target_repo}:{extra_tag}'

                manifest_blobref = oci_client.head_manifest(
                    image_reference=push_target,
                    absent_ok=True,
                    accept=replication_mode.accept_header(),
                )
                if manifest_blobref and manifest_blobref.digest == oci_manifest_digest:
                    logger.info(
                      f'skipping {push_target=}: already present {oci_manifest_digest=}'
                    )
                    continue
                try:
                    oci_client.put_manifest(
                        image_reference=push_target,
                        manifest=manifest_bytes,
                    )
                except requests.exceptions.HTTPError as e:
                    if (
                        e.response is not None
                        and e.response.status_code == 409
                        and replication_resource_element.ignore_extra_tag_policy_violations
                    ):
                        logger.warning(
                            f'pushing extra tag {push_target=} was rejected by tag policy '
                            f'(409) - ignoring as configured'
                        )
                    else:
                        raise

        if digest := replication_resource_element.target.digest:
            # if resource has a digest we understand, and is an ociArtifact, then we need to
            # update the digest, because we might have changed the oci-artefact
            if (
                digest.hashAlgorithm.upper() == 'SHA-256'
                and digest.normalisationAlgorithm == ocm.NormalisationAlgorithm.OCI_ARTIFACT_DIGEST
            ):
                digest.value = oci_manifest_digest.removeprefix('sha256:')
                replication_resource_element.target.digest = digest

        if replication_resource_element.convert_to_relative_ref:
            # remove host from target ref
            replication_resource_element.target.access = ocm.RelativeOciAccess(
                reference=om.OciImageReference(
                    image_reference=replication_resource_element.tgt_ref,
                    normalise=False, # don't inject docker special handlings
                ).local_ref,
            )

        if replication_resource_element.reference_by_digest:
            tgt_ref = replication_resource_element.tgt_ref

            if (
                replication_resource_element.retain_symbolic_tag
                and (tgt_ref.has_symbolical_tag or tgt_ref.has_mixed_tag)
            ):
                tgt_ref = f'{tgt_ref.with_symbolical_tag}@{oci_manifest_digest}'
            else:
                tgt_ref = f'{tgt_ref.ref_without_tag}@{oci_manifest_digest}'

            access_type = replication_resource_element.target.access.type
            if access_type is ocm.AccessType.OCI_REGISTRY:
                replication_resource_element.target.access.imageReference = tgt_ref
            elif access_type is ocm.AccessType.RELATIVE_OCI_REFERENCE:
                replication_resource_element.target.access.reference = tgt_ref
            else:
                raise ValueError(access_type)

        if descriptor_ref := replication_resource_element.descriptor_ref_override:
            # overwrite the ref written into the component-descriptor, independently of where
            # the artifact was actually pushed; the access-type is always OCI_REGISTRY here,
            # since descriptor_ref_override is an absolute reference
            replication_resource_element.target.access = ocm.OciAccess(
                imageReference=descriptor_ref,
            )

        return replication_resource_element

    def wrap_process_resource(replication_resource_element: ctt.model.ReplicationResourceElement):
        try:
            return process_replication_resource_element(replication_resource_element)
        except Exception as e:
            logger.error(f'exception while processing {replication_resource_element=}')
            raise e

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
    replication_resource_elements = tuple(executor.map(
        wrap_process_resource,
        replication_plan_step.resources,
    ))

    # --- SBOM injection (between Phase 1 image uploads and Phase 2 descriptor patching) ---
    # Maps component_identity → list of extra OCM resource dicts to append.
    sbom_extra_resources: dict[ocm.ComponentIdentity, list[dict]] = collections.defaultdict(list)

    sbom_candidates = [
        rre for rre in replication_resource_elements
        if rre.inject_sboms
    ]
    if sbom_candidates:
        if processing_mode is not ProcessingMode.DRY_RUN:
            sbom_inject.check_syft()
            sbom_inject.check_cbomkit_theia()

        tmpdir = os.environ.get('TMPDIR') or os.environ.get('RUNNER_TEMP') or None
        syft_ver = sbom_inject._syft_version()

        # parallel referrer lookup
        def _lookup(rre):
            tgt_ref = rre.tgt_ref
            # resolve to digest; use multiarch accept so registries serve index manifests
            digest_ref_str = oci_client.to_digest_hash(
                tgt_ref,
                accept=replication_mode.accept_header(),
            )
            digest_ref = om.OciImageReference.to_image_ref(digest_ref_str)

            # if the manifest is a multiarch index, resolve to linux/amd64 so syft
            # can scan a concrete single-platform manifest (some registries reject
            # index manifest requests when the Accept header doesn't include index types)
            try:
                manifest = oci_client.manifest(
                    digest_ref,
                    accept=replication_mode.accept_header(),
                )
                if isinstance(manifest, om.OciImageManifestList):
                    entries = [
                        e for e in manifest.manifests
                        if e.platform and e.platform.os == 'linux'
                        and e.platform.architecture == 'amd64'
                    ] or (manifest.manifests[:1] if manifest.manifests else [])
                    if entries:
                        plat_digest = entries[0].digest
                        digest_ref = om.OciImageReference.to_image_ref(
                            f'{digest_ref.ref_without_tag}@{plat_digest}'
                        )
            except Exception:  # nosec B110
                pass  # keep the index digest ref; scan will fail gracefully

            hit = sbom_inject.lookup_sbom_referrers(
                image_ref=digest_ref,
                oci_client=oci_client,
            )
            return rre, digest_ref, hit

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as lk_exec:
            lookup_results = list(lk_exec.map(_lookup, sbom_candidates))

        hits = [(rre, dref, hit) for rre, dref, hit in lookup_results if hit is not None]
        misses = [(rre, dref) for rre, dref, hit in lookup_results if hit is None]

        logger.info(
            f'SBOM injection: {len(hits)} cache hit(s), {len(misses)} cache miss(es)'
        )

        # process cache hits
        for rre, dref, hit in hits:
            spdx_bytes, cdx_bytes, spdx_ref_digest, cdx_ref_digest = hit
            tool_ver = sbom_inject._syft_version_from_spdx(spdx_bytes)
            cbom_tool_ver = sbom_inject._cbomkit_theia_version()
            repo_ref = dref.ref_without_tag
            source_image_ref = str(rre.src_ref)
            source_digest = dref.tag  # sha256:<hex>

            # generate CBOM from the existing CycloneDX SBOM — no image re-download
            cbom_referrer_digest = None
            if processing_mode is not ProcessingMode.DRY_RUN:
                try:
                    with tempfile.TemporaryDirectory(dir=tmpdir or None) as _tmp:
                        cdx_path = os.path.join(_tmp, 'sbom.cdx.json')
                        cbom_path = os.path.join(_tmp, 'cbom.cdx.json')
                        with open(cdx_path, 'wb') as _f:
                            _f.write(cdx_bytes)
                        sbom_inject._run_cbomkit_theia(
                            image_ref=str(dref),
                            cdx_bom_path=cdx_path,
                            out_path=cbom_path,
                            tmpdir=_tmp,
                        )
                        with open(cbom_path, 'rb') as _f:
                            cbom_bytes = _f.read()
                        cbom_referrer_digest = sbom_cbom.push_cbom_referrer(
                            cbom_bytes=cbom_bytes,
                            image_reference=dref,
                            oci_client=oci_client,
                            tool_version=cbom_tool_ver,
                        )
                except Exception as e:
                    logger.warning(f'{rre.source.name!r}: CBOM generation failed: {e}')

            spdx_res, cdx_res, cbom_res = sbom_inject.build_sbom_ocm_resources(
                resource_name=rre.source.name,
                version=rre.source.version,
                source_image_ref=source_image_ref,
                source_digest=source_digest,
                repo_ref=repo_ref,
                spdx_referrer_digest=spdx_ref_digest,
                cdx_referrer_digest=cdx_ref_digest,
                cbom_referrer_digest=cbom_referrer_digest or '',
                tool_ver=tool_ver,
                cbom_tool_ver=cbom_tool_ver,
                source_extra_identity=rre.source.extraIdentity or None,
            )
            extra = [spdx_res, cdx_res]
            if cbom_referrer_digest:
                extra.append(cbom_res)
            sbom_extra_resources[rre.component_id].extend(extra)

        # process cache misses (resource-aware scans)
        if misses and processing_mode is not ProcessingMode.DRY_RUN:
            # key by digest-ref string (unique per image) to avoid name collisions
            miss_items = [(str(dref), dref) for rre, dref in misses]
            miss_map = {str(dref): (rre, dref) for rre, dref in misses}

            scan_results = sbom_inject.run_injections_resource_aware(
                items=miss_items,
                oci_client=oci_client,
                tmpdir=tmpdir or '/tmp',  # nosec B108
                tool_ver=syft_ver,
            )
            for (key, spdx_bytes, cdx_bytes, cbom_bytes,
                 tool_ver, cbom_tool_ver,
                 spdx_dig, cdx_dig, cbom_dig, status) in scan_results:
                if status != 'scanned':
                    continue
                rre, dref = miss_map[key]
                repo_ref = dref.ref_without_tag
                source_digest = dref.tag
                spdx_res, cdx_res, cbom_res = sbom_inject.build_sbom_ocm_resources(
                    resource_name=rre.source.name,
                    version=rre.source.version,
                    source_image_ref=str(rre.src_ref),
                    source_digest=source_digest,
                    repo_ref=repo_ref,
                    spdx_referrer_digest=spdx_dig,
                    cdx_referrer_digest=cdx_dig,
                    cbom_referrer_digest=cbom_dig,
                    tool_ver=tool_ver,
                    cbom_tool_ver=cbom_tool_ver,
                    source_extra_identity=rre.source.extraIdentity or None,
                )
                sbom_extra_resources[rre.component_id].extend((spdx_res, cdx_res, cbom_res))

    # --- S3 SBOM injection ---
    # Scans S3-backed resources from the component descriptors and injects SBOM/CBOM resources.
    # Enabled only when inject_s3_sboms=True (default: False).
    if inject_s3_sboms:
        if processing_mode is not ProcessingMode.DRY_RUN:
            sbom_inject.check_syft()

        tmpdir = os.environ.get('TMPDIR') or os.environ.get('RUNNER_TEMP') or '/tmp'  # nosec B108
        syft_ver = sbom_inject._syft_version()
        registry_base = replication_plan_step.target_ocm_repository

        # collect all S3 resources across all components in this replication step
        s3_candidates = [
            (rce.target.component, resource)
            for rce in replication_plan_step.components
            for resource in rce.target.component.resources
            if isinstance(resource.access, (ocm.S3Access, ocm.LegacyS3Access))
        ]

        logger.info(f'S3 SBOM injection: {len(s3_candidates)} S3 resource(s) to process')

        for component, resource in s3_candidates:
            component_id = component.identity()
            access = resource.access

            if isinstance(access, ocm.LegacyS3Access):
                s3_url = sbom_s3.s3_url(access.bucketName, access.objectKey, access.region)
            else:
                s3_url = sbom_s3.s3_url(access.bucket, access.key, access.region)

            if processing_mode is ProcessingMode.DRY_RUN:
                logger.info(
                    f'dry-run: would scan S3 resource {resource.name!r} ({s3_url})'
                )
                continue

            try:
                (spdx_bytes, cdx_bytes, cbom_bytes,
                 tool_ver, cbom_tool_ver,
                 spdx_digest, cdx_digest, cbom_digest,
                 repo_ref, content_digest) = sbom_inject.scan_s3_resource(
                    access=access,
                    oci_client=oci_client,
                    registry_base=registry_base,
                    tmpdir=tmpdir,
                    tool_ver=syft_ver,
                )
            except Exception as e:
                logger.warning(
                    f'{resource.name!r}: S3 SBOM scan failed: {e}'
                )
                continue

            spdx_res, cdx_res, cbom_res = sbom_inject.build_s3_sbom_ocm_resources(
                resource_name=resource.name,
                version=resource.version,
                s3_url=s3_url,
                content_digest=content_digest,
                repo_ref=repo_ref,
                spdx_manifest_digest=spdx_digest,
                cdx_manifest_digest=cdx_digest,
                cbom_manifest_digest=cbom_digest,
                tool_ver=tool_ver,
                cbom_tool_ver=cbom_tool_ver,
                source_extra_identity=resource.extraIdentity or None,
            )
            sbom_extra_resources[component_id].extend((spdx_res, cdx_res, cbom_res))
            logger.info(
                f'{resource.name!r}: S3 SBOM/CBOM injected '
                f'(spdx={spdx_digest[:16]}... cdx={cdx_digest[:16]}...)'
            )

    # --- Phase 2: component-descriptor patching ---
    is_root_component_descriptor = lambda component_descriptor: (
        component_descriptor.component.name == root_component_descriptor.component.name
        and component_descriptor.component.version == root_component_descriptor.component.version
    )

    for replication_plan_component in replication_plan_step.components:
        if is_root_component_descriptor(replication_plan_component.target):
            # store modified root target component descriptor because `ocm.iter.iter` won't
            # resolve the (updated) root component descriptor again
            root_component_descriptor = replication_plan_component.target

        component = replication_plan_component.target.component

        resource_group = [
            replication_resource_element.target
            for replication_resource_element in replication_resource_elements
            if replication_resource_element.component_id == component.identity()
        ]

        patched_resources = {}

        # patch-in overwrites (caveat: must be done sequentially, as lists are not threadsafe)
        # use copy of resources as peers to shortcut "self"-check in identity function
        peer_resources = [
            copy.deepcopy(resource)
            for resource in component.resources
        ]

        for resource in resource_group:
            patched_resources[resource.identity(peer_resources)] = resource

        component.resources = [
            patched_resources.get(resource.identity(peer_resources), resource)
            for resource in component.resources
        ]

        # append any SBOM resources injected for this component
        fresh = sbom_extra_resources.get(component.identity(), ())
        if fresh:
            # strip stale SBOM/CBOM resources so fresh ones are the only source of truth
            component.resources = [
                r for r in component.resources
                if 'cbom-format' not in (r.extraIdentity or {})
                and 'sbom-format' not in (r.extraIdentity or {})
            ]
        for sbom_resource in fresh:
            component.resources.append(sbom_resource)

        # Validate the patched component-descriptor and exit on fail
        if not skip_cd_validation:
            # ensure component-descriptor is json-serialisable
            raw = dataclasses.asdict(replication_plan_component.target)
            try:
                raw_json = json.dumps(raw, cls=ctt_util.EnumJSONEncoder)
            except Exception as e:
                logger.error(f'Component-Descriptor could not be json-serialised: {e}')
                raise
            try:
                raw = json.loads(raw_json)
            except Exception as e:
                logger.error(f'Component-Descriptor could not be deserialised: {e}')
                raise

            try:
                ocm.ComponentDescriptor.validate(raw, validation_mode=ocm.ValidationMode.FAIL)
            except jsonschema.exceptions.RefResolutionError as rre:
                logger.warning(
                    'error whilst resolving reference from json-schema (see below) - will ignore'
                )
                print(rre)
            except Exception as e:
                component_id = f'{component.name}:{component.version}'
                logger.warning(
                    f'Schema validation for component-descriptor {component_id} failed with {e}'
                )

        # publish the (patched) component-descriptors
        if skip_component_upload and skip_component_upload(component):
            continue

        if processing_mode is ProcessingMode.DRY_RUN:
            print('dry-run - will not publish component-descriptor')
            continue
        elif processing_mode is not ProcessingMode.REGULAR:
            raise NotImplementedError(processing_mode)

        if len(ocm_repos := component.repositoryContexts) >= 2:
            orig_ocm_repo = component.repositoryContexts[-2]
        elif len(ocm_repos) == 1:
            logger.warning(f'{component.name}:{component.version} has only one ocm-repository')
            logger.warning('(expected: two or more)')
            logger.warning(f'{ocm_repos=}')
            orig_ocm_repo = component.repositoryContexts[-1]
        else:
            raise RuntimeError(f'{component.name}:{component.version} has no ocm-repository')

        ctt.replicate.replicate_oci_artifact_with_patched_component_descriptor(
            src_name=component.name,
            src_version=component.version,
            patched_component_descriptor=replication_plan_component.target,
            src_ocm_repo=orig_ocm_repo,
            oci_client=oci_client,
            overwrite=overwrite_descriptors,
            rewrite_local_blobs=local_blobs_mode is LocalBlobsMode.COPY_BY_REFERENCE,
        )

    if processing_mode is ProcessingMode.DRY_RUN:
        return # early exit because components cannot be retrieved from target

    # retrieve component descriptor from the target registry as local descriptor might not contain
    # patched image references (if it was already existing the the target registry and thus patching
    # has been skipped)
    if patched_root_component_descriptor := tgt_component_descriptor_lookup(
        root_component_descriptor.component.identity(),
        absent_ok=True,
    ):
        root_component_descriptor = patched_root_component_descriptor

    for node in ocm.iter.iter(
        component=root_component_descriptor,
        lookup=tgt_component_descriptor_lookup,
        component_filter=component_filter,
        reftype_filter=reftype_filter,
    ):
        if ocm.iter.Filter.components(node):
            pass
        elif ocm.iter.Filter.resources(node):
            node: ocm.iter.ResourceNode

            if node.resource.access.type not in (
                ocm.AccessType.OCI_REGISTRY,
                ocm.AccessType.RELATIVE_OCI_REFERENCE,
            ):
                continue
        else:
            continue

        yield node
