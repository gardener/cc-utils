# SPDX-FileCopyrightText: Contributors to the Gardener project
#
# SPDX-License-Identifier: Apache-2.0

import abc
import collections.abc
import re

import ctt.model
import ocm


# characters permitted (between alphanumerics) in an OCI repository path-component
_repo_component_illegal = re.compile(r'[^a-z0-9._-]')


def mangle_repo_component(
    value: str,
    replacement_char: str='_',
) -> str:
    '''
    lower-cases `value` and replaces characters not permitted in an OCI repository path-component
    with `replacement_char`. Not injective (e.g. `V1` and `v1` both map to `v1`); as callers only
    ever fold this into a repository-name suffix (never into a tag), a collision merely co-locates
    two distinct tags in the same repository - it can never overwrite.
    '''
    return _repo_component_illegal.sub(replacement_char, value.lower())


class UploaderBase:
    @abc.abstractmethod
    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        raise NotImplementedError('must be implemented by its subclasses')


class PrependTargetUploader(UploaderBase):
    def __init__(
        self,
        mangle: bool=True,
        mangle_replacement_char: str='_',
        convert_to_relative_refs: bool=False,
        remove_prefixes: list[str]=[],
    ):
        self._mangle = mangle
        self._mangle_replacement_char = mangle_replacement_char
        self._convert_to_relative_refs = convert_to_relative_refs
        self._remove_prefixes = remove_prefixes

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        tgt_oci_registry: str,
        target_as_source: bool=False,
    ) -> ctt.model.ReplicationResourceElement:
        supported_access_types = (
            ocm.AccessType.OCI_REGISTRY,
            ocm.AccessType.RELATIVE_OCI_REFERENCE,
        )
        if replication_resource_element.source.access.type not in supported_access_types:
            raise RuntimeError(f'PrependTargetUploader only supports {supported_access_types=}')

        if not target_as_source:
            src_ref = replication_resource_element.src_ref
        else:
            src_ref = replication_resource_element.tgt_ref

        src_base_ref = src_ref.ref_without_tag

        for remove_prefix in self._remove_prefixes:
            src_base_ref = src_base_ref.removeprefix(remove_prefix)

        if self._mangle:
            src_base_ref = src_base_ref.replace('.', self._mangle_replacement_char)

        # if a prefix is to be removed from existing src base ref, it is likely that it should be
        # replaced by the new prefix, instead of only prepended (where a joining `/` is reasonable).
        # Instead, leave it up to the configuration to decide on the joining character.
        if not self._remove_prefixes:
            tgt_ref = '/'.join((
                tgt_oci_registry.rstrip('/'),
                src_base_ref.lstrip('/'),
            ))
        else:
            tgt_ref = tgt_oci_registry + src_base_ref

        if src_ref.has_mixed_tag:
            symbolical_tag, digest_tag = src_ref.parsed_mixed_tag
            tgt_ref = f'{tgt_ref}:{symbolical_tag}@{digest_tag}'
        elif src_ref.has_digest_tag:
            tgt_ref = f'{tgt_ref}@{src_ref.tag}'
        elif src_ref.has_symbolical_tag:
            tgt_ref = f'{tgt_ref}:{src_ref.tag}'

        if src_ref.has_digest_tag:
            replication_resource_element.reference_by_digest = True

        if self._convert_to_relative_refs:
            replication_resource_element.convert_to_relative_ref = True

        replication_resource_element.target.access = ocm.OciAccess(
            imageReference=tgt_ref,
        )

        return replication_resource_element


class RepositoryUploader(UploaderBase):
    def __init__(
        self,
        repository: str | None=None,
        mangle: bool=True,
        mangle_replacement_char: str='_',
        convert_to_relative_refs: bool=False,
        remove_prefixes: list[str]=[],
    ):
        self._repository = repository
        self._mangle = mangle
        self._mangle_replacement_char = mangle_replacement_char
        self._convert_to_relative_refs = convert_to_relative_refs
        self._remove_prefixes = remove_prefixes

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        tgt_oci_registry: str,
        target_as_source: bool=False,
    ) -> ctt.model.ReplicationResourceElement:
        supported_access_types = (
            ocm.AccessType.OCI_REGISTRY,
            ocm.AccessType.RELATIVE_OCI_REFERENCE,
        )
        if replication_resource_element.source.access.type not in supported_access_types:
            raise RuntimeError(f'RepositoryUploader only supports {supported_access_types=}')

        if not target_as_source:
            src_ref = replication_resource_element.src_ref
        else:
            src_ref = replication_resource_element.tgt_ref

        src_base_ref = src_ref.ref_without_tag

        for remove_prefix in self._remove_prefixes:
            src_base_ref = src_base_ref.removeprefix(remove_prefix)

        if self._mangle:
            src_base_ref = src_base_ref.replace('.', self._mangle_replacement_char)

        if self._repository:
            tgt_ref = '/'.join((
                tgt_oci_registry.rstrip('/'),
                self._repository.lstrip('/'),
            ))
        else:
            tgt_ref = tgt_oci_registry

        # if a prefix is to be removed from existing src base ref, it is likely that it should be
        # replaced by the new prefix, instead of only prepended (where a joining `/` is reasonable).
        # Instead, leave it up to the configuration to decide on the joining character.
        if not self._remove_prefixes:
            tgt_ref = '/'.join((
                tgt_ref.rstrip('/'),
                src_base_ref.lstrip('/'),
            ))
        else:
            tgt_ref = tgt_ref + src_base_ref

        if src_ref.has_mixed_tag:
            symbolical_tag, digest_tag = src_ref.parsed_mixed_tag
            tgt_ref = f'{tgt_ref}:{symbolical_tag}@{digest_tag}'
        elif src_ref.has_digest_tag:
            tgt_ref = f'{tgt_ref}@{src_ref.tag}'
        elif src_ref.has_symbolical_tag:
            tgt_ref = f'{tgt_ref}:{src_ref.tag}'

        if src_ref.has_digest_tag:
            replication_resource_element.reference_by_digest = True

        if self._convert_to_relative_refs:
            replication_resource_element.convert_to_relative_ref = True

        replication_resource_element.target.access = ocm.OciAccess(
            imageReference=tgt_ref,
        )

        return replication_resource_element


class TagSuffixUploader(UploaderBase):
    def __init__(
        self,
        suffix,
        separator='-',
    ):
        self._suffix = suffix
        self._separator = separator

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        target_as_source: bool=False,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        if replication_resource_element.source.access.type is not ocm.AccessType.OCI_REGISTRY:
            raise RuntimeError(f'TagSuffixUploader only supports {ocm.AccessType.OCI_REGISTRY=}')

        if not target_as_source:
            src_ref = replication_resource_element.src_ref
        else:
            src_ref = replication_resource_element.tgt_ref

        if src_ref.has_digest_tag:
            raise RuntimeError('Cannot append tag suffix to resource that is accessed via digest')

        tgt_tag = self._separator.join((src_ref.tag, self._suffix))
        tgt_ref = ':'.join((src_ref.ref_without_tag, tgt_tag))

        replication_resource_element.target.access = ocm.OciAccess(
            imageReference=tgt_ref,
        )

        return replication_resource_element


class ExtraTagUploader(UploaderBase):
    '''
    Uploader that will push additional tags to uploaded images.

    extra_tags: a static list of tags (e.g. "latest"). Will be overwritten if present
    tag_expressions: a list of tag-expressions that will be evaluated
    excluded_artefact_types: artefact-types (ocm.ArtefactType values or raw strings) for which
        no extra tags are pushed; useful when multiple artefact types share the same repository
        (e.g. spdx-documents alongside oci-images) and the target registry forbids retagging
    skip_all_types_except: if given, only artefacts whose type is in this list receive extra tags;
        all others are skipped (mutually exclusive with `excluded_artefact_types`)
    skip_retagging: if True, no extra tags are ever pushed regardless of other settings

    tag_expressions are python-expressions and will be evaluated with the following scope:

    ```
    resource: the OCM-Resource (see ocm package)
    ```

    As an example, the following expression might be used to restore "symbolic tags" from
    OCM-metadata, like so:
    ```
    uploaders:
        restore_symbolic_tag:
            type: ExtraTagUploader
            kwargs:
                tag_expressions:
                    - '{resource.version}'
                excluded_artefact_types:
                    - blob/v1
    ```
    '''
    def __init__(
        self,
        extra_tags: collections.abc.Iterable[str]=(),
        tag_expressions: collections.abc.Iterable[str]=(),
        excluded_artefact_types: collections.abc.Iterable[str]=(),
        skip_all_types_except: collections.abc.Iterable[str] | None=None,
        skip_retagging: bool=False,
        ignore_tag_policy_violations: bool=False,
    ):
        if excluded_artefact_types and skip_all_types_except is not None:
            raise ValueError(
                'excluded_artefact_types and skip_all_types_except are mutually exclusive'
            )
        self.extra_tags = list(extra_tags)
        self.tag_expressions = list(tag_expressions)
        self._excluded_types = {str(t) for t in excluded_artefact_types}
        self._allowed_types = (
            {str(t) for t in skip_all_types_except}
            if skip_all_types_except is not None
            else None
        )
        self._skip_retagging = skip_retagging
        self._ignore_tag_policy_violations = ignore_tag_policy_violations

    def _should_skip(self, resource: ocm.Resource) -> bool:
        if self._skip_retagging:
            return True
        rtype = str(resource.type)
        if self._excluded_types and rtype in self._excluded_types:
            return True
        if self._allowed_types is not None and rtype not in self._allowed_types:
            return True
        return False

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        resource = replication_resource_element.target

        if self._should_skip(resource):
            replication_resource_element.extra_tags = []
            return replication_resource_element

        replication_resource_element.extra_tags = list(self.extra_tags)
        replication_resource_element.ignore_extra_tag_policy_violations = (
            self._ignore_tag_policy_violations
        )

        for expr in self.tag_expressions:
            res = eval( # nosec B307
                expr,
                {'resource': resource},
            )
            if not isinstance(res, str):
                raise ValueError(f'{expr=} did not yield str, but {type(res)=}')
            replication_resource_element.extra_tags.append(res)

        return replication_resource_element


class DigestUploader(UploaderBase):
    '''
    sets `reference_target_by_digest` attribute in upload-request, which will result in
    target-component-descriptor's resouce's access use digest rather than tag to reference
    oci image. If `retain_symbolic_tag` is set, the symbolic tag is kept and the digest
    is appended, otherwise the digest overwrites the symbolic tag.
    '''
    def __init__(
        self,
        retain_symbolic_tag: bool=False,
    ):
        self._retain_symbolic_tag = retain_symbolic_tag

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        replication_resource_element.reference_by_digest = True
        replication_resource_element.retain_symbolic_tag = self._retain_symbolic_tag

        return replication_resource_element


class TagFoldingUploader(UploaderBase):
    '''
    Isolates each image-version into its own target repository by folding the tag into the
    repository-name. This bounds the number of manifests/blobs per repository (to one image-version
    each) to work around OCI-registries that impose an implicit limit on the amount of
    manifests/layer-blobs within a single repository.

    The mapping is a pure function of the (already computed) target image-reference, hence stable
    and independent of run-composition or ordering. It therefore requires neither persisted state
    nor a pre-calculation pass, and remains safe for incremental (partial) replication runs.

    Must run _after_ the uploader that sets the push target (e.g. PrependTargetUploader): it reads
    the base target ref, appends the (mangled) tag to `ref_without_tag`, and re-attaches the
    original tag. Example (base target `tgt-registry/my-image`):

        tgt-registry/my-image:v1  ->  tgt-registry/my-image-v1:v1
        tgt-registry/my-image:v2  ->  tgt-registry/my-image-v2:v2
        tgt-registry/my-image:v3  ->  tgt-registry/my-image-v3:v3

    Note: the total image-reference grows longer; some registries impose a max-length. Shortening
    is not yet implemented (kept out until a test-run shows it is needed).
    '''
    def __init__(
        self,
        separator: str='-',
        mangle_replacement_char: str='_',
    ):
        self._separator = separator
        self._mangle_replacement_char = mangle_replacement_char

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        target_as_source: bool=False,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        if not target_as_source:
            src_ref = replication_resource_element.src_ref
        else:
            src_ref = replication_resource_element.tgt_ref

        if src_ref.has_mixed_tag:
            fold_source, _ = src_ref.parsed_mixed_tag
        else:
            fold_source = src_ref.tag

        tgt_base_ref = self._separator.join((
            src_ref.ref_without_tag,
            mangle_repo_component(fold_source, self._mangle_replacement_char),
        ))

        if src_ref.has_mixed_tag:
            symbolical_tag, digest_tag = src_ref.parsed_mixed_tag
            tgt_ref = f'{tgt_base_ref}:{symbolical_tag}@{digest_tag}'
        elif src_ref.has_digest_tag:
            tgt_ref = f'{tgt_base_ref}@{src_ref.tag}'
        else:
            tgt_ref = f'{tgt_base_ref}:{src_ref.tag}'

        if src_ref.has_digest_tag:
            replication_resource_element.reference_by_digest = True

        replication_resource_element.target.access = ocm.OciAccess(
            imageReference=tgt_ref,
        )

        return replication_resource_element


class DescriptorRefRewriteUploader(UploaderBase):
    '''
    Rewrites the image-reference written into the component-descriptor without changing the actual
    push target.  This is useful when the OCI registry the artifacts are pushed to differs from
    the one clients are supposed to pull from (e.g. a primary region registry vs. a global CDN
    endpoint that geo-routes to regional replicas).

    `src_prefix` is matched against the beginning of the target ref (as computed by any preceding
    uploaders) and replaced by `tgt_prefix`.  Both values are compared/applied on the full
    image-reference string including the host.

    Example cfg:
    ```yaml
    uploaders:
      rewrite_for_global:
        type: DescriptorRefRewriteUploader
        kwargs:
          src_prefix: keppel.eu-de-1.cloud.sap/
          tgt_prefix: keppel.global.cloud.sap/
    ```
    '''
    def __init__(
        self,
        src_prefix: str,
        tgt_prefix: str,
    ):
        self._src_prefix = src_prefix
        self._tgt_prefix = tgt_prefix

    def process(
        self,
        replication_resource_element: ctt.model.ReplicationResourceElement,
        /,
        target_as_source: bool=False,
        **kwargs,
    ) -> ctt.model.ReplicationResourceElement:
        if not target_as_source:
            ref = str(replication_resource_element.src_ref)
        else:
            ref = str(replication_resource_element.tgt_ref)

        if not ref.startswith(self._src_prefix):
            raise ValueError(
                f'{ref!r} does not start with {self._src_prefix!r}; '
                'check DescriptorRefRewriteUploader configuration'
            )

        descriptor_ref = self._tgt_prefix + ref.removeprefix(self._src_prefix)
        replication_resource_element.descriptor_ref_override = descriptor_ref

        return replication_resource_element
