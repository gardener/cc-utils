import argparse
import logging

import ocm.retrieve
import ctt.process_dependencies
import oci.auth
import oci.client
import oci.workarounds

'''
exposes a CLI for "CTT" (fka: CNUDIE Transport Tool)
'''


def _init_logging():
    '''
    initialises logging to some hardcoded defaults (default cfg is too taciturn).
    '''
    logging.basicConfig(
        level=logging.INFO,
    )


def configure_parser(parser):
    parser.add_argument(
        '--src-repo',
        required=True,
        help='path to OCM-Repository-Root',
    )
    parser.add_argument(
        '--ocm-component',
        required=True,
        help='the OCM-Component-version to replicate (format: <name>:<version>)',
    )
    parser.add_argument(
        '--docker-config',
        default=None,
    )
    parser.add_argument(
        '--processing-cfg',
        required=True,
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        default=False,
    )
    parser.add_argument(
        '--jobs', '-j',
        type=int,
        default=8,
        help='how many replication-tasks should be run in parallel.',
    )
    parser.add_argument(
        '--retries',
        type=int,
        default=5,
        help='how many times to retry a failed OCI request',
    )
    parser.add_argument(
        '--retry-backoff-seconds',
        type=float,
        default=1.0,
        help='initial sleep before first retry; doubles on each subsequent attempt',
    )
    parser.add_argument(
        '--max-concurrency-per-host',
        type=int,
        default=8,
        help=(
            'initial maximum number of simultaneous in-flight requests to any single registry '
            'host. Per-target overrides in processing.cfg (max_concurrency) take precedence.'
        ),
    )
    parser.add_argument(
        '--pruning-mode',
        type=ctt.process_dependencies.PruningMode,
        choices=ctt.process_dependencies.PruningMode,
        default=ctt.process_dependencies.PruningMode.PRUNE_SUBTREES,
        help=(
            'controls tree-pruning behaviour. '
            f'"{ctt.process_dependencies.PruningMode.PRUNE_SUBTREES.value}" (default) '
            'skips subtrees already present in the target. '
            f'"{ctt.process_dependencies.PruningMode.REPLICATE_ALL.value}" '
            'replicates the full transitive closure unconditionally. '
            f'"{ctt.process_dependencies.PruningMode.FORCE_OVERWRITE_DESCRIPTORS.value}" '
            'replicates the full transitive closure and overwrites existing component-descriptors; '
            'OCI artefacts are still skipped when already present.'
        ),
    )

    parser.add_argument(
        '--inject-s3-sboms',
        action='store_true',
        default=False,
        help='scan S3-backed resources and inject SBOM/CBOM documents into replicated descriptors',
    )
    blob_existence_group = parser.add_mutually_exclusive_group()
    blob_existence_group.add_argument(
        '--blob-existence-check-via-get',
        action='store_true',
        default=False,
        help=(
            'check blob-existence via GET instead of HEAD. Works around registries (observed: '
            'Artifactory) that can inconsistently answer HEAD=200/GET=404 for the same, actually '
            'absent, blob.'
        ),
    )
    blob_existence_group.add_argument(
        '--always-upload-blobs',
        action='store_true',
        default=False,
        help=(
            'unconditionally treat blobs as absent, forcing every blob to be re-uploaded. Works '
            'around registries (observed: Artifactory) that report a blob as present (HEAD/GET '
            'both 20x) yet still reject the manifest-PUT referencing it.'
        ),
    )
    parser.add_argument(
        '--paranoid',
        action='store_true',
        default=False,
        help=(
            'validate each uploaded oci-manifest via GET after successful PUT, failing the '
            'replication if it is not actually served. Works around registries (observed: '
            'Artifactory) that accept manifest-PUTs with HTTP 20x while silently dropping the '
            'manifest (subsequent GETs yield HTTP 404).'
        ),
    )


def replicate(parsed):
    _init_logging()
    if not ':' in parsed.ocm_component:
        print(f'{parsed.ocm_component=} does not match expected format (<name>:<version>)')
        exit(1)

    oci_client = oci.client.Client(
        credentials_lookup=oci.auth.docker_credentials_lookup(
            docker_cfg=parsed.docker_config,
        ),
        max_retries=parsed.retries,
        default_backoff_base_seconds=parsed.retry_backoff_seconds,
        max_concurrency_per_host=parsed.max_concurrency_per_host,
    )

    if parsed.blob_existence_check_via_get:
        oci.workarounds.patch_head_blob_to_use_get(oci_client)
    elif parsed.always_upload_blobs:
        oci.workarounds.patch_head_blob_to_ignore_existing_blobs(oci_client)

    component_descriptor_lookup = ocm.retrieve.create_default_component_descriptor_lookup(
        ocm_repository_lookup=ocm.retrieve.ocm_repository_lookup(parsed.src_repo),
        oci_client=oci_client,
    )

    component_descriptor = component_descriptor_lookup(
        parsed.ocm_component,
        absent_ok=False, # let the exception propagate to convey a detailed error-message
    )

    if parsed.dry_run:
        processing_mode = ctt.process_dependencies.ProcessingMode.DRY_RUN
    else:
        processing_mode = ctt.process_dependencies.ProcessingMode.REGULAR

    max_workers = parsed.jobs
    if max_workers < 0:
        print('--jobs must be positive or 0')
        exit(1)
    elif max_workers == 0:
        max_workers = None

    print(f'starting replication of {parsed.ocm_component} {processing_mode=}')
    for _ in ctt.process_dependencies.process_images(
        processing_cfg_path=parsed.processing_cfg,
        root_component_descriptor=component_descriptor,
        component_descriptor_lookup=component_descriptor_lookup,
        oci_client=oci_client,
        processing_mode=processing_mode,
        max_workers=max_workers,
        pruning_mode=parsed.pruning_mode,
        inject_s3_sboms=parsed.inject_s3_sboms,
        paranoid=parsed.paranoid,
    ):
        pass


def main():
    parser = argparse.ArgumentParser()
    configure_parser(parser)

    parsed = parser.parse_args()

    replicate(parsed)


if __name__ == '__main__':
    main()
